"""
Embed Result Figures into Thesis
==================================
Author  : Rakan Abunamoos
Thesis  : Detection of SQL Injection Using Machine Learning (XGBoost)

PURPOSE:
  Reads the thesis .docx file, finds the 8 figure placeholder paragraphs,
  and replaces each with the actual PNG image from results/.

  Run this script ONCE after downloading the thesis .docx file.

REQUIREMENTS:
  pip install python-docx Pillow

USAGE:
  python embed_figures.py

INPUT  : thesis_rakan_abunamoos.docx  (in same folder as this script)
OUTPUT : thesis_rakan_abunamoos_with_figures.docx
"""

import os
import sys
from pathlib import Path

try:
    from docx import Document
    from docx.shared import Inches, Pt, RGBColor
    from docx.enum.text import WD_ALIGN_PARAGRAPH
    from docx.oxml.ns import qn
    from docx.oxml import OxmlElement
    import copy
except ImportError:
    print("ERROR: python-docx not installed.")
    print("Run:  pip install python-docx Pillow")
    sys.exit(1)

# ── CONFIG ────────────────────────────────────────────────────────────────────

BASE_DIR    = Path(__file__).parent
RESULTS_DIR = BASE_DIR / "results"
INPUT_DOCX  = BASE_DIR / "thesis_rakan_abunamoos.docx"
OUTPUT_DOCX = BASE_DIR / "thesis_rakan_abunamoos_with_figures.docx"

# Maps: placeholder text → (image filename, width in inches, caption text)
FIGURE_MAP = {
    "[Insert figure: results/sqli_eda.png]": (
        "sqli_eda.png", 6.0,
        "Figure 6.1: EDA — class distribution, query length histogram, and feature correlation matrix"
    ),
    "[Insert figure: results/test_confusion_matrix.png]": (
        "test_confusion_matrix.png", 3.5,
        "Figure 6.2: Confusion matrix — test set (TP=1,683  TN=2,911  FP=18  FN=24)"
    ),
    "[Insert figure: results/test_roc_curve.png]": (
        "test_roc_curve.png", 3.5,
        "Figure 6.3: ROC curve — test set (AUC = 0.9983)"
    ),
    "[Insert figure: results/feature_importance.png]": (
        "feature_importance.png", 5.5,
        "Figure 6.4: XGBoost gain-based feature importance (sorted by contribution)"
    ),
    "[Insert figure: results/shap_summary.png]": (
        "shap_summary.png", 6.0,
        "Figure 6.5: SHAP summary plot — test set (each point = one sample, colored by feature value)"
    ),
    "[Insert figure: results/ablation_chart.png]": (
        "ablation_chart.png", 6.0,
        "Figure 6.6: Feature ablation — F1 without each feature (left) and F1 drop % (right)"
    ),
    "[Insert figure: results/generalization_results.png]": (
        "generalization_results.png", 6.0,
        "Figure 6.7: Generalization test — detected vs. missed, benchmark comparison, in/out distribution"
    ),
    "[Insert figure: results/dvwa_breakdown.png]": (
        "dvwa_breakdown.png", 6.0,
        "Figure 6.8: DVWA evaluation — by attack type, by security level, latency distribution"
    ),
}

# ── HELPERS ───────────────────────────────────────────────────────────────────

def set_para_alignment(para, alignment):
    """Set paragraph alignment."""
    para.alignment = alignment


def add_image_to_paragraph(para, image_path, width_inches):
    """Clear paragraph content and add an image run."""
    # Clear existing runs
    for run in para.runs:
        run.text = ""

    # Add image run
    run = para.add_run()
    run.add_picture(str(image_path), width=Inches(width_inches))
    para.alignment = WD_ALIGN_PARAGRAPH.CENTER


def find_and_replace_placeholder(doc, placeholder_text, image_path, width_inches, caption):
    """Find paragraph with placeholder text and replace it with image."""
    replaced = False

    for i, para in enumerate(doc.paragraphs):
        if placeholder_text in para.text:
            print(f"  Found: '{placeholder_text[:50]}'")

            # Replace the placeholder paragraph with the image
            para.clear()
            run = para.add_run()

            if not image_path.exists():
                # If image not found, keep a note
                run.text = f"[IMAGE NOT FOUND: {image_path.name}]"
                run.font.color.rgb = RGBColor(0xFF, 0x00, 0x00)
                print(f"    ⚠️  Image not found: {image_path}")
            else:
                run.add_picture(str(image_path), width=Inches(width_inches))
                para.alignment = WD_ALIGN_PARAGRAPH.CENTER
                print(f"    ✅ Embedded: {image_path.name} ({width_inches} inches wide)")

            replaced = True
            break

    return replaced

# ── MAIN ──────────────────────────────────────────────────────────────────────

def embed_figures():
    print("=" * 60)
    print("  EMBEDDING FIGURES INTO THESIS")
    print("=" * 60)

    if not INPUT_DOCX.exists():
        print(f"ERROR: thesis file not found at {INPUT_DOCX}")
        print("Place this script in the same folder as thesis_rakan_abunamoos.docx")
        sys.exit(1)

    print(f"[LOAD]  Opening {INPUT_DOCX.name} ...")
    doc = Document(str(INPUT_DOCX))

    # Check which images exist
    print(f"\n[CHECK] Checking images in {RESULTS_DIR} ...")
    missing = []
    for placeholder, (img_name, width, caption) in FIGURE_MAP.items():
        img_path = RESULTS_DIR / img_name
        status = "✅" if img_path.exists() else "❌ MISSING"
        print(f"  {status}  {img_name}")
        if not img_path.exists():
            missing.append(img_name)

    if missing:
        print(f"\n⚠️  {len(missing)} images missing. Run these scripts first:")
        if "sqli_eda.png" in missing:
            print("     python src/preprocessing.py")
        if any("confusion" in m or "roc" in m or "shap" in m or "importance" in m for m in missing):
            print("     python src/evaluate.py")
        if "ablation_chart.png" in missing:
            print("     python src/ablation_study.py")
        if "generalization" in str(missing):
            print("     python src/generalization_test.py")
        if "dvwa" in str(missing):
            print("     python src/dvwa_evaluation.py")
        print("\nContinuing with available images...\n")

    # Replace placeholders
    print("\n[EMBED] Replacing figure placeholders ...")
    embedded = 0
    for placeholder, (img_name, width, caption) in FIGURE_MAP.items():
        img_path = RESULTS_DIR / img_name
        success  = find_and_replace_placeholder(doc, placeholder, img_path, width, caption)
        if success and img_path.exists():
            embedded += 1

    # Save
    print(f"\n[SAVE]  Writing {OUTPUT_DOCX.name} ...")
    doc.save(str(OUTPUT_DOCX))

    print("\n" + "=" * 60)
    print("  EMBEDDING COMPLETE")
    print("=" * 60)
    print(f"  Images embedded : {embedded}/{len(FIGURE_MAP)}")
    print(f"  Output file     : {OUTPUT_DOCX.name}")
    print("=" * 60)
    print("\n  Open thesis_rakan_abunamoos_with_figures.docx in Word.")
    print("  The [Insert figure] placeholders are now replaced with images.")
    print("=" * 60)


if __name__ == "__main__":
    embed_figures()
