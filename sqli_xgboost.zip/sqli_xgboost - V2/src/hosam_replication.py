"""
SQL Injection Detection — Hosam et al. (2021) Same-Dataset Replication
========================================================================
Author  : Rakan Abunamoos
Thesis  : Detection of SQL Injection Using Machine Learning (XGBoost)
Uni     : Uskudar University — Cybersecurity MSc 2025-2026

PURPOSE:
  Hosam, Hosny, Ashraf & Kaseb (2021) trained/tested on a "Balanced-Kaggle"
  split (11,104 malicious + 12,200 benign, 70/30 train/test) drawn from the
  same public Kaggle SQL Injection Dataset this thesis uses, then tested
  generalization on an "All-Attacks" set of 2,102 malicious-only payloads.
  Their exact processed files are not reachable (dead 2021 bit.ly link), so
  this script replicates their documented methodology on our copy of the
  same base dataset and reports a direct, same-data comparison — rather
  than comparing against their published numbers on an unverified split.

  This is a SEPARATE, standalone experiment. It does NOT touch the main
  pipeline's artifacts (model/xgboost_model.pkl, model/scaler.pkl,
  data/processed/*.csv) — everything it produces is prefixed
  "hosam_replication".

METHODOLOGY:
  1. Load + clean the raw Kaggle CSV (same cleaning as preprocessing.py).
  2. Undersample the benign class so malicious:benign matches Hosam's
     Balanced-Kaggle ratio (11,104 : 12,200), seed=42.
  3. Stratified 70/30 train/test split (matching their ratio; they used no
     validation split for this experiment).
  4. Extract the same 8 engineered features used throughout this thesis
     (this feature set was itself adopted from Hosam et al.'s top-ranked
     features, so it is a fair basis for both sides of the comparison).
  5. Tune + train XGBoost on the train split (RandomizedSearchCV, same
     search space as train.py).
  6. Evaluate accuracy on the held-out 30% test split — compared directly
     to Hosam's Table V Kaggle-test accuracy figures.
  7. Evaluate the same trained model on this thesis's existing libinjection
     generalization corpus (data/generalization/sqli-*.txt) — compared
     directly to Hosam's All-Attacks accuracy (87.3%, Logistic Regression).
     Note: their All-Attacks set was 2,102 payloads; ours is much larger
     (~47K) — this scale difference is reported, not hidden.

OUTPUT:
  model/hosam_replication_xgboost_model.pkl
  model/hosam_replication_scaler.pkl
  results/hosam_replication_report.json
  results/hosam_replication_comparison.png

Run   : python src/hosam_replication.py
"""

import os
import re
import json
import pickle
import time
import numpy as np
import pandas as pd
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
from sklearn.model_selection import train_test_split, RandomizedSearchCV, StratifiedKFold
from sklearn.preprocessing import StandardScaler
from sklearn.metrics import accuracy_score, precision_score, recall_score, f1_score
from xgboost import XGBClassifier

# ─── 0. PATHS ─────────────────────────────────────────────────────────────────

BASE_DIR      = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
RAW_DATA_PATH = os.path.join(BASE_DIR, "data", "raw", "sqli_dataset.csv")
GEN_DIR       = os.path.join(BASE_DIR, "data", "generalization")
MODEL_DIR     = os.path.join(BASE_DIR, "model")
RESULTS_DIR   = os.path.join(BASE_DIR, "results")

MODEL_PATH    = os.path.join(MODEL_DIR,   "hosam_replication_xgboost_model.pkl")
SCALER_PATH   = os.path.join(MODEL_DIR,   "hosam_replication_scaler.pkl")
REPORT_PATH   = os.path.join(RESULTS_DIR, "hosam_replication_report.json")
PLOT_PATH     = os.path.join(RESULTS_DIR, "hosam_replication_comparison.png")

RANDOM_SEED = 42

# Hosam et al. (2021) Table III — Balanced-Kaggle class sizes
HOSAM_BAL_MALICIOUS = 11104
HOSAM_BAL_BENIGN    = 12200

# Hosam et al. (2021) Table V — accuracy figures (%)
HOSAM_RESULTS = {
    "Logistic Regression":     {"exp1_13feat": 99.3, "exp2_8feat": 99.1, "exp3_generalization": 87.3},
    "Gradient Boosting":       {"exp1_13feat": 99.3, "exp2_8feat": 99.2, "exp3_generalization": 79.5},
    "Decision Tree":           {"exp1_13feat": 99.6, "exp2_8feat": 99.3, "exp3_generalization": 85.0},
    "Random Forest":           {"exp1_13feat": 98.6, "exp2_8feat": 98.6, "exp3_generalization": 80.6},
    "Support Vector Machines": {"exp1_13feat": 98.4, "exp2_8feat": 99.2, "exp3_generalization": 83.4},
    "Neural Networks":         {"exp1_13feat": 99.3, "exp2_8feat": 99.3, "exp3_generalization": 82.3},
}
HOSAM_ALL_ATTACKS_SIZE = 2102

FEATURE_COLS = [
    "query_length",
    "num_keywords",
    "num_special_chars",
    "num_comments",
    "num_semicolons",
    "num_arithmetic",
    "num_union",
    "num_always_true",
]

# ─── 1. SQL PATTERNS (must match preprocessing.py exactly) ────────────────────

SQL_KEYWORDS = [
    "select", "insert", "update", "delete", "drop", "create", "alter",
    "union", "from", "where", "having", "order", "group", "by", "join",
    "inner", "outer", "left", "right", "on", "into", "values", "set",
    "exec", "execute", "xp_", "sp_", "cast", "convert", "char", "nchar",
    "varchar", "declare", "table", "database", "schema", "truncate",
    "information_schema", "sysobjects", "syscolumns",
]

ALWAYS_TRUE_PATTERNS = [
    r"or\s+1\s*=\s*1",
    r"or\s+'[^']*'\s*=\s*'[^']*'",
    r"or\s+\"[^\"]*\"\s*=\s*\"[^\"]*\"",
    r"or\s+true",
    r"1\s*=\s*1",
    r"'[^']+'\s*=\s*'[^']+'",
]


def clean_query(raw: str) -> str:
    if not isinstance(raw, str):
        return ""
    s = raw
    s = s.replace("%27", "'").replace("%22", '"')
    s = s.replace("%20", " ").replace("%09", "\t")
    s = s.replace("%2D", "-").replace("%23", "#")
    s = s.replace("%3D", "=").replace("%3B", ";")
    s = s.replace("+", " ")
    s = re.sub(r"&[a-zA-Z]+;", " ", s)
    s = re.sub(r"&#\d+;",      " ", s)
    s = re.sub(r"\s+",         " ", s).strip()
    s = s.lower()
    return s


def extract_features(query: str) -> list:
    q = query
    return [
        len(q),
        sum(len(re.findall(rf"\b{re.escape(kw)}\b", q)) for kw in SQL_KEYWORDS),
        len(re.findall(r"['\"`]", q)),
        len(re.findall(r"(--|#|/\*|\*/)", q)),
        q.count(";"),
        len(re.findall(r"(=|<|>|!=|<>|\band\b|\bor\b|\bnot\b)", q)),
        len(re.findall(r"\bunion\b", q)),
        sum(len(re.findall(p, q)) for p in ALWAYS_TRUE_PATTERNS),
    ]

# ─── 2. BUILD BALANCED-KAGGLE-STYLE SPLIT ──────────────────────────────────────

def build_balanced_kaggle(raw_path: str):
    print("=" * 60)
    print("  STEP 1 — Build Balanced-Kaggle-style dataset")
    print("=" * 60)

    df = pd.read_csv(raw_path)
    df.columns = [c.strip().lower() for c in df.columns]
    df = df.rename(columns={"query": "query", "label": "label"})
    df = df.dropna(subset=["query", "label"])
    df["query"] = df["query"].astype(str)
    df["label"] = df["label"].astype(int)
    before = len(df)
    df = df.drop_duplicates(subset=["query"])
    print(f"[CLEAN] {before:,} -> {len(df):,} rows after dropping nulls/duplicates")

    benign    = df[df["label"] == 0]
    malicious = df[df["label"] == 1]
    print(f"[RAW]   Benign: {len(benign):,}  Malicious: {len(malicious):,}")

    # Match Hosam's Balanced-Kaggle ratio (benign:malicious = 12200:11104)
    ratio = HOSAM_BAL_BENIGN / HOSAM_BAL_MALICIOUS
    target_benign = min(len(benign), int(round(len(malicious) * ratio)))

    benign_sampled = benign.sample(n=target_benign, random_state=RANDOM_SEED)
    balanced = pd.concat([benign_sampled, malicious], ignore_index=True)
    balanced = balanced.sample(frac=1.0, random_state=RANDOM_SEED).reset_index(drop=True)

    print(f"[BAL]   Sampled benign: {len(benign_sampled):,}  "
          f"(Hosam Balanced-Kaggle: {HOSAM_BAL_BENIGN:,})")
    print(f"[BAL]   Malicious (all): {len(malicious):,}  "
          f"(Hosam Balanced-Kaggle: {HOSAM_BAL_MALICIOUS:,})")
    print(f"[BAL]   Total: {len(balanced):,}  "
          f"(Hosam Balanced-Kaggle: {HOSAM_BAL_MALICIOUS + HOSAM_BAL_BENIGN:,})")

    balanced["query_clean"] = balanced["query"].apply(clean_query)
    feat = balanced["query_clean"].apply(lambda q: pd.Series(extract_features(q), index=FEATURE_COLS))
    balanced = pd.concat([balanced, feat], axis=1)

    X = balanced[FEATURE_COLS].values
    y = balanced["label"].values

    # 70/30 split — matches Hosam's methodology (no separate val split)
    X_train, X_test, y_train, y_test = train_test_split(
        X, y, test_size=0.30, random_state=RANDOM_SEED, stratify=y,
    )
    print(f"\n[SPLIT] 70/30  (Hosam: 16,312 train / 6,992 test)")
    print(f"        Train: {len(X_train):,}  Test: {len(X_test):,}")

    return X_train, X_test, y_train, y_test

# ─── 3. TRAIN XGBOOST ──────────────────────────────────────────────────────────

def train_xgboost(X_train, y_train):
    print("\n" + "=" * 60)
    print("  STEP 2 — Train XGBoost on Balanced-Kaggle-style split")
    print("=" * 60)

    scaler = StandardScaler()
    X_train_scaled = scaler.fit_transform(X_train)

    neg = int(np.sum(y_train == 0))
    pos = int(np.sum(y_train == 1))
    scale_pos_weight = round(neg / pos, 4)
    print(f"[IMB]   Train -> Benign:{neg:,}  Malicious:{pos:,}  "
          f"scale_pos_weight={scale_pos_weight}")

    param_dist = {
        "n_estimators":     [100, 200, 300, 500],
        "max_depth":        [3, 4, 5, 6, 7],
        "learning_rate":    [0.01, 0.05, 0.1, 0.2],
        "subsample":        [0.7, 0.8, 0.9, 1.0],
        "colsample_bytree": [0.7, 0.8, 0.9, 1.0],
        "min_child_weight": [1, 3, 5],
    }
    base_model = XGBClassifier(
        scale_pos_weight=scale_pos_weight,
        eval_metric="logloss",
        random_state=RANDOM_SEED,
        n_jobs=1,
    )
    cv = StratifiedKFold(n_splits=5, shuffle=True, random_state=RANDOM_SEED)
    search = RandomizedSearchCV(
        estimator=base_model,
        param_distributions=param_dist,
        n_iter=20,
        scoring="f1",
        cv=cv,
        verbose=1,
        n_jobs=-1,
        random_state=RANDOM_SEED,
        refit=True,
    )

    t0 = time.time()
    search.fit(X_train_scaled, y_train)
    elapsed = round(time.time() - t0, 1)
    print(f"[TUNE]  Best params : {search.best_params_}")
    print(f"[TUNE]  Best CV F1  : {search.best_score_:.4f}")
    print(f"[TUNE]  Time        : {elapsed}s")

    return search.best_estimator_, scaler, search.best_params_

# ─── 4. EVALUATE ON HELD-OUT TEST SPLIT ────────────────────────────────────────

def evaluate_test_split(model, scaler, X_test, y_test):
    print("\n" + "=" * 60)
    print("  STEP 3 — Evaluate on held-out Balanced-Kaggle-style test set")
    print("=" * 60)

    X_test_scaled = scaler.transform(X_test)
    y_pred = model.predict(X_test_scaled)

    acc  = accuracy_score(y_test, y_pred)
    prec = precision_score(y_test, y_pred, zero_division=0)
    rec  = recall_score(y_test, y_pred, zero_division=0)
    f1   = f1_score(y_test, y_pred, zero_division=0)

    print(f"  Accuracy  : {acc*100:.2f}%")
    print(f"  Precision : {prec*100:.2f}%")
    print(f"  Recall    : {rec*100:.2f}%")
    print(f"  F1-score  : {f1*100:.2f}%")
    print("\n  Hosam et al. (2021) Table V, 8-feature (Exp.2), Kaggle test accuracy:")
    for name, vals in HOSAM_RESULTS.items():
        print(f"    {name:<24}: {vals['exp2_8feat']:.1f}%")
    print(f"    {'This thesis XGBoost':<24}: {acc*100:.2f}%  "
          f"[{'+' if acc*100 >= 99.1 else ''}{acc*100 - 99.1:.2f} pp vs. their LR]")

    return {"accuracy": round(acc, 4), "precision": round(prec, 4),
            "recall": round(rec, 4), "f1": round(f1, 4)}

# ─── 5. EVALUATE ON EXISTING LIBINJECTION GENERALIZATION CORPUS ───────────────

def evaluate_generalization(model, scaler, gen_dir: str):
    print("\n" + "=" * 60)
    print("  STEP 4 — Evaluate on existing libinjection generalization corpus")
    print("=" * 60)

    sqli_files = sorted([
        f for f in os.listdir(gen_dir)
        if f.startswith("sqli-") and f.endswith(".txt")
    ])
    if not sqli_files:
        print("[WARN]  No sqli-*.txt files found — skipping generalization test.")
        return None

    all_rows = []
    for fname in sqli_files:
        path = os.path.join(gen_dir, fname)
        with open(path, "r", encoding="utf-8", errors="ignore") as f:
            lines = [l.strip() for l in f if l.strip() and not l.startswith("#")]
        all_rows.extend(lines)

    attack_df = pd.DataFrame({"query": all_rows})
    before = len(attack_df)
    attack_df = attack_df.drop_duplicates(subset=["query"])
    print(f"[LOAD]  {len(sqli_files)} files, {before:,} payloads, "
          f"{len(attack_df):,} unique (Hosam All-Attacks: {HOSAM_ALL_ATTACKS_SIZE:,})")

    attack_df["query_clean"] = attack_df["query"].apply(clean_query)
    X = np.array([extract_features(q) for q in attack_df["query_clean"]], dtype=float)
    X_scaled = scaler.transform(X)

    y_pred = model.predict(X_scaled)
    detected = int(np.sum(y_pred == 1))
    total    = len(y_pred)
    det_rate = detected / total

    print(f"\n  Detection rate on {total:,} unseen malicious payloads: "
          f"{det_rate*100:.2f}%")
    print(f"  Hosam et al. (2021) All-Attacks ({HOSAM_ALL_ATTACKS_SIZE:,} payloads), "
          f"Logistic Regression: 87.3%")
    print(f"  Delta vs. their benchmark: {det_rate*100 - 87.3:+.2f} pp")
    print(f"  NOTE: their All-Attacks set was {HOSAM_ALL_ATTACKS_SIZE:,} payloads; "
          f"this corpus is {total:,} — scale differs, methodology matches.")

    return {
        "total_payloads": total,
        "detected": detected,
        "detection_rate": round(det_rate, 4),
        "detection_pct": round(det_rate * 100, 2),
        "hosam_all_attacks_size": HOSAM_ALL_ATTACKS_SIZE,
        "hosam_lr_benchmark_pct": 87.3,
        "delta_vs_hosam_lr_pp": round(det_rate * 100 - 87.3, 2),
    }

# ─── 6. PLOT ────────────────────────────────────────────────────────────────

def save_plot(test_metrics, gen_results, output_path):
    fig, axes = plt.subplots(1, 2, figsize=(12, 5))
    fig.suptitle("Same-Dataset Replication of Hosam (2021) Methodology",
                 fontsize=13, fontweight="bold")

    # Plot 1: Kaggle test accuracy, all Hosam models + ours
    ax = axes[0]
    names  = list(HOSAM_RESULTS.keys()) + ["This Thesis\n(XGBoost)"]
    values = [v["exp2_8feat"] for v in HOSAM_RESULTS.values()] + [test_metrics["accuracy"] * 100]
    colors = ["#AAAAAA"] * len(HOSAM_RESULTS) + ["#3B8BD4"]
    bars = ax.barh(names, values, color=colors, edgecolor="white")
    for bar, v in zip(bars, values):
        ax.text(v + 0.1, bar.get_y() + bar.get_height() / 2, f"{v:.1f}%",
                va="center", fontsize=9)
    ax.set_xlim(95, 101)
    ax.set_title("Balanced-Kaggle Test Accuracy (8 features)", fontsize=11)
    ax.spines[["top", "right"]].set_visible(False)

    # Plot 2: Generalization comparison
    if gen_results:
        ax = axes[1]
        names2  = ["Hosam\n(2021) LR\n(2,102 payloads)",
                   "This Thesis\nXGBoost\n(libinjection corpus)"]
        values2 = [87.3, gen_results["detection_pct"]]
        bars = ax.bar(names2, values2, color=["#AAAAAA", "#3B8BD4"],
                      edgecolor="white", width=0.5)
        for bar, v in zip(bars, values2):
            ax.text(bar.get_x() + bar.get_width() / 2, v + 0.5, f"{v:.2f}%",
                    ha="center", va="bottom", fontsize=11)
        ax.set_ylim(0, 110)
        ax.set_title("Generalization Detection Rate", fontsize=11)
        ax.spines[["top", "right"]].set_visible(False)

    plt.tight_layout()
    plt.savefig(output_path, dpi=150, bbox_inches="tight")
    plt.close()
    print(f"\n[PLOT]  Saved -> {output_path}")

# ─── 7. MAIN ────────────────────────────────────────────────────────────────

def run():
    os.makedirs(MODEL_DIR, exist_ok=True)
    os.makedirs(RESULTS_DIR, exist_ok=True)

    X_train, X_test, y_train, y_test = build_balanced_kaggle(RAW_DATA_PATH)
    model, scaler, best_params = train_xgboost(X_train, y_train)
    test_metrics = evaluate_test_split(model, scaler, X_test, y_test)
    gen_results  = evaluate_generalization(model, scaler, GEN_DIR)

    with open(MODEL_PATH, "wb") as f:
        pickle.dump(model, f)
    with open(SCALER_PATH, "wb") as f:
        pickle.dump(scaler, f)
    print(f"\n[SAVE]  Model  -> {MODEL_PATH}")
    print(f"[SAVE]  Scaler -> {SCALER_PATH}")

    report = {
        "methodology": "Same-dataset replication of Hosam et al. (2021)",
        "balanced_kaggle_target": {
            "malicious": HOSAM_BAL_MALICIOUS,
            "benign": HOSAM_BAL_BENIGN,
        },
        "best_params": best_params,
        "test_metrics": test_metrics,
        "hosam_table_v_kaggle_test_accuracy_pct": {k: v["exp2_8feat"] for k, v in HOSAM_RESULTS.items()},
        "generalization": gen_results,
    }
    with open(REPORT_PATH, "w") as f:
        json.dump(report, f, indent=2)
    print(f"[SAVE]  Report -> {REPORT_PATH}")

    save_plot(test_metrics, gen_results, PLOT_PATH)

    print("\n" + "=" * 60)
    print("  REPLICATION COMPLETE")
    print("=" * 60)
    return report


if __name__ == "__main__":
    run()
