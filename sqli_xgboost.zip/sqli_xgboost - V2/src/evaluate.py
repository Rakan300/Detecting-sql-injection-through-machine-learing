"""
SQL Injection Detection — Final Evaluation on Test Set
=======================================================
Author  : Rakan Abunamoos
Thesis  : Detection of SQL Injection Using Machine Learning (XGBoost)
Uni     : Uskudar University — Cybersecurity MSc 2025-2026

Input  : data/processed/sqli_test.csv
         model/xgboost_model.pkl
         model/model_metadata.json

Output : results/test_report.json
         results/test_confusion_matrix.png
         results/test_roc_curve.png
         results/shap_summary.png          ← SHAP explainability

Run    : python src/evaluate.py

⚠️  Run this ONCE after training is finalized.
    Do NOT use test results to tune the model — that causes data leakage.
"""

import os
import json
import pickle
import numpy as np
import pandas as pd
import matplotlib.pyplot as plt
import seaborn as sns
from sklearn.metrics import (
    accuracy_score, precision_score, recall_score,
    f1_score, roc_auc_score, confusion_matrix,
    roc_curve, classification_report,
)

# ─── 0. PATHS ─────────────────────────────────────────────────────────────────

BASE_DIR      = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
PROC_DIR      = os.path.join(BASE_DIR, "data",    "processed")
MODEL_DIR     = os.path.join(BASE_DIR, "model")
RESULTS_DIR   = os.path.join(BASE_DIR, "results")

TEST_PATH     = os.path.join(PROC_DIR,    "sqli_test.csv")
MODEL_PATH    = os.path.join(MODEL_DIR,   "xgboost_model.pkl")
METADATA_PATH = os.path.join(MODEL_DIR,   "model_metadata.json")
REPORT_PATH   = os.path.join(RESULTS_DIR, "test_report.json")
CM_PATH       = os.path.join(RESULTS_DIR, "test_confusion_matrix.png")
ROC_PATH      = os.path.join(RESULTS_DIR, "test_roc_curve.png")
SHAP_PATH     = os.path.join(RESULTS_DIR, "shap_summary.png")

# ─── 1. LOAD ──────────────────────────────────────────────────────────────────

def load_test():
    df = pd.read_csv(TEST_PATH)
    X  = df.drop(columns=["label"]).values
    y  = df["label"].values
    feature_cols = [c for c in df.columns if c != "label"]
    print(f"[LOAD]  Test set: {X.shape[0]:,} samples, {X.shape[1]} features")
    return X, y, feature_cols


def load_model():
    with open(MODEL_PATH, "rb") as f:
        model = pickle.load(f)
    print(f"[LOAD]  Model loaded ← {MODEL_PATH}")
    return model


def load_metadata():
    with open(METADATA_PATH) as f:
        return json.load(f)

# ─── 2. EVALUATION ────────────────────────────────────────────────────────────

def evaluate(model, X_test, y_test, feature_cols: list):
    y_pred = model.predict(X_test)
    y_prob = model.predict_proba(X_test)[:, 1]

    acc  = accuracy_score(y_test, y_pred)
    prec = precision_score(y_test, y_pred, zero_division=0)
    rec  = recall_score(y_test, y_pred, zero_division=0)
    f1   = f1_score(y_test, y_pred, zero_division=0)
    auc  = roc_auc_score(y_test, y_prob)

    print("\n[RESULTS]  Final Test Set Evaluation")
    print("─" * 40)
    print(f"  Accuracy  : {acc:.4f}  ({acc*100:.2f}%)")
    print(f"  Precision : {prec:.4f}")
    print(f"  Recall    : {rec:.4f}")
    print(f"  F1-score  : {f1:.4f}")
    print(f"  AUC-ROC   : {auc:.4f}")
    print("─" * 40)
    print("\n[REPORT]  Full classification report:")
    print(classification_report(
        y_test, y_pred,
        target_names=["Benign (0)", "Malicious (1)"]
    ))

    target_met = f1 >= 0.95
    print(f"[TARGET]  F1 ≥ 0.95 → {'✅ MET' if target_met else '❌ NOT MET'}")

    cm = confusion_matrix(y_test, y_pred)
    tn, fp, fn, tp = cm.ravel()
    print(f"\n[CM]      TP:{tp}  TN:{tn}  FP:{fp}  FN:{fn}")
    print(f"          False Positive Rate : {fp/(fp+tn):.4f}")
    print(f"          False Negative Rate : {fn/(fn+tp):.4f}")

    metrics = {
        "accuracy":            round(acc,  4),
        "precision":           round(prec, 4),
        "recall":              round(rec,  4),
        "f1":                  round(f1,   4),
        "auc_roc":             round(auc,  4),
        "tp": int(tp), "tn": int(tn),
        "fp": int(fp), "fn": int(fn),
        "false_positive_rate": round(fp/(fp+tn), 4),
        "false_negative_rate": round(fn/(fn+tp), 4),
        "f1_target_met":       target_met,
    }
    return metrics, y_pred, y_prob

# ─── 3. PLOTS ─────────────────────────────────────────────────────────────────

def plot_confusion_matrix(y_test, y_pred, output_path: str):
    cm = confusion_matrix(y_test, y_pred)
    fig, ax = plt.subplots(figsize=(6, 5))
    sns.heatmap(
        cm, annot=True, fmt="d", cmap="Blues",
        xticklabels=["Benign", "Malicious"],
        yticklabels=["Benign", "Malicious"],
        ax=ax, linewidths=0.5, annot_kws={"size": 14},
    )
    ax.set_xlabel("Predicted Label", fontsize=12)
    ax.set_ylabel("True Label",      fontsize=12)
    ax.set_title("Confusion Matrix — Test Set", fontsize=13, fontweight="bold")
    plt.tight_layout()
    plt.savefig(output_path, dpi=150, bbox_inches="tight")
    plt.close()
    print(f"[PLOT]  Confusion matrix → {output_path}")


def plot_roc_curve(y_test, y_prob, output_path: str):
    fpr, tpr, _ = roc_curve(y_test, y_prob)
    auc = roc_auc_score(y_test, y_prob)
    fig, ax = plt.subplots(figsize=(6, 5))
    ax.plot(fpr, tpr, color="#3B8BD4", lw=2,
            label=f"XGBoost (AUC = {auc:.4f})")
    ax.plot([0, 1], [0, 1], color="gray", linestyle="--", lw=1, label="Random")
    ax.fill_between(fpr, tpr, alpha=0.1, color="#3B8BD4")
    ax.set_xlabel("False Positive Rate", fontsize=12)
    ax.set_ylabel("True Positive Rate",  fontsize=12)
    ax.set_title("ROC Curve — Test Set", fontsize=13, fontweight="bold")
    ax.legend(loc="lower right")
    ax.spines[["top", "right"]].set_visible(False)
    plt.tight_layout()
    plt.savefig(output_path, dpi=150, bbox_inches="tight")
    plt.close()
    print(f"[PLOT]  ROC curve        → {output_path}")


def plot_shap(model, X_test, feature_cols: list, output_path: str):
    """SHAP explainability — shows which features drive each prediction."""
    try:
        import shap
        explainer   = shap.TreeExplainer(model)
        shap_values = explainer.shap_values(X_test)

        fig, ax = plt.subplots(figsize=(8, 5))
        shap.summary_plot(
            shap_values, X_test,
            feature_names=feature_cols,
            show=False, plot_type="bar",
        )
        plt.title("SHAP Feature Importance — Test Set",
                  fontsize=13, fontweight="bold")
        plt.tight_layout()
        plt.savefig(output_path, dpi=150, bbox_inches="tight")
        plt.close()
        print(f"[PLOT]  SHAP summary     → {output_path}")

    except ImportError:
        print("[SHAP]  shap not installed — skipping SHAP plot.")
        print("        Install with:  pip install shap")

# ─── 4. MAIN ──────────────────────────────────────────────────────────────────

def run_evaluation():
    os.makedirs(RESULTS_DIR, exist_ok=True)

    print("=" * 60)
    print("  SQL INJECTION — FINAL TEST SET EVALUATION")
    print("=" * 60)

    X_test, y_test, feature_cols = load_test()
    model = load_model()
    meta  = load_metadata()

    metrics, y_pred, y_prob = evaluate(model, X_test, y_test, feature_cols)

    plot_confusion_matrix(y_test, y_pred, CM_PATH)
    plot_roc_curve(y_test, y_prob, ROC_PATH)
    plot_shap(model, X_test, feature_cols, SHAP_PATH)

    # Save report
    report = {"test_metrics": metrics, "feature_cols": feature_cols}
    with open(REPORT_PATH, "w") as f:
        json.dump(report, f, indent=2)
    print(f"\n[SAVE]  Test report → {REPORT_PATH}")

    print("\n" + "=" * 60)
    print("  EVALUATION COMPLETE")
    print("=" * 60)
    print(f"  Accuracy  : {metrics['accuracy']:.4f}")
    print(f"  Precision : {metrics['precision']:.4f}")
    print(f"  Recall    : {metrics['recall']:.4f}")
    print(f"  F1-score  : {metrics['f1']:.4f}")
    print(f"  AUC-ROC   : {metrics['auc_roc']:.4f}")
    print(f"  F1 ≥ 0.95 : {'✅ MET' if metrics['f1_target_met'] else '❌ NOT MET'}")
    print("=" * 60)
    print("\n  Next step → run:  python src/predict.py")
    print("=" * 60)

    return metrics


if __name__ == "__main__":
    run_evaluation()
