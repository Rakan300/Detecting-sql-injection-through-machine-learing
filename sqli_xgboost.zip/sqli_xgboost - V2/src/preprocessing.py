"""
SQL Injection Detection — Preprocessing Pipeline
=================================================
Author  : Rakan Abunamoos
Thesis  : Detection of SQL Injection Using Machine Learning (XGBoost)
Uni     : Uskudar University — Cybersecurity MSc 2025-2026

Output files:
  data/processed/sqli_train.csv
  data/processed/sqli_val.csv
  data/processed/sqli_test.csv
  model/scaler.pkl
  model/model_metadata.json
  results/sqli_eda.png
"""

import os
import re
import json
import pickle
import numpy as np
import pandas as pd
import matplotlib.pyplot as plt
import seaborn as sns
from datetime import datetime
from sklearn.model_selection import train_test_split
from sklearn.preprocessing import StandardScaler

# ─── 0. PATHS ─────────────────────────────────────────────────────────────────

BASE_DIR       = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
RAW_DATA_PATH  = os.path.join(BASE_DIR, "data", "raw",       "sqli_dataset.csv")
PROC_DIR       = os.path.join(BASE_DIR, "data", "processed")
MODEL_DIR      = os.path.join(BASE_DIR, "model")
RESULTS_DIR    = os.path.join(BASE_DIR, "results")

SCALER_PATH    = os.path.join(MODEL_DIR, "scaler.pkl")
METADATA_PATH  = os.path.join(MODEL_DIR, "model_metadata.json")
EDA_PLOT_PATH  = os.path.join(RESULTS_DIR, "sqli_eda.png")

# ─── 1. CONFIG ────────────────────────────────────────────────────────────────

RANDOM_SEED = 42
TEST_SIZE   = 0.15
VAL_SIZE    = 0.15   # fraction of the ORIGINAL dataset

FEATURE_COLS = [
    "query_length",
    "num_keywords",
    "num_special_chars",
    "num_comments",
    "num_semicolons",
    "num_arithmetic",
    "num_union",
    "num_always_true",
]

# ─── 2. SQL PATTERNS ──────────────────────────────────────────────────────────

SQL_KEYWORDS = [
    "select", "insert", "update", "delete", "drop", "create", "alter",
    "union", "from", "where", "having", "order", "group", "by", "join",
    "inner", "outer", "left", "right", "on", "into", "values", "set",
    "exec", "execute", "xp_", "sp_", "cast", "convert", "char", "nchar",
    "varchar", "declare", "table", "database", "schema", "truncate",
    "information_schema", "sysobjects", "syscolumns",
]

ALWAYS_TRUE_PATTERNS = [
    r"or\s+1\s*=\s*1",
    r"or\s+'[^']*'\s*=\s*'[^']*'",
    r"or\s+\"[^\"]*\"\s*=\s*\"[^\"]*\"",
    r"or\s+true",
    r"1\s*=\s*1",
    r"'[^']+'\s*=\s*'[^']+'",
]

# ─── 3. LOAD ──────────────────────────────────────────────────────────────────

def load_dataset(path: str) -> pd.DataFrame:
    df = pd.read_csv(path)
    df.columns = [c.strip().lower() for c in df.columns]

    rename_map = {}
    for col in df.columns:
        if col in ("sentence", "query", "payload", "input", "text"):
            rename_map[col] = "query"
        if col in ("label", "class", "target", "type"):
            rename_map[col] = "label"
    df = df.rename(columns=rename_map)

    if "query" not in df.columns or "label" not in df.columns:
        raise ValueError(
            f"Could not find 'query' and 'label' columns. Found: {list(df.columns)}"
        )

    print(f"[LOAD]  {len(df):,} rows loaded from '{path}'")
    return df[["query", "label"]]

# ─── 4. CLEAN ─────────────────────────────────────────────────────────────────

def clean_query(raw: str) -> str:
    """Normalize a raw SQL string while preserving injection signals."""
    if not isinstance(raw, str):
        return ""
    s = raw
    # URL decode
    s = s.replace("%27", "'").replace("%22", '"')
    s = s.replace("%20", " ").replace("%09", "\t")
    s = s.replace("%2D", "-").replace("%23", "#")
    s = s.replace("%3D", "=").replace("%3B", ";")
    s = s.replace("+",   " ")
    # Strip HTML entities
    s = re.sub(r"&[a-zA-Z]+;", " ", s)
    s = re.sub(r"&#\d+;",      " ", s)
    # Collapse whitespace
    s = re.sub(r"\s+", " ", s).strip()
    # Lowercase
    s = s.lower()
    return s

# ─── 5. FEATURE EXTRACTION ────────────────────────────────────────────────────

def extract_features(query: str) -> dict:
    """Extract 8 numeric features from a cleaned query string."""
    q = query

    query_length = len(q)

    num_keywords = sum(
        len(re.findall(rf"\b{re.escape(kw)}\b", q))
        for kw in SQL_KEYWORDS
    )

    num_special_chars = len(re.findall(r"['\"`]", q))

    num_comments = len(re.findall(r"(--|#|/\*|\*/)", q))

    num_semicolons = q.count(";")

    num_arithmetic = len(re.findall(
        r"(=|<|>|!=|<>|\band\b|\bor\b|\bnot\b)", q
    ))

    num_union = len(re.findall(r"\bunion\b", q))

    num_always_true = sum(
        len(re.findall(p, q))
        for p in ALWAYS_TRUE_PATTERNS
    )

    return {
        "query_length":     query_length,
        "num_keywords":     num_keywords,
        "num_special_chars": num_special_chars,
        "num_comments":     num_comments,
        "num_semicolons":   num_semicolons,
        "num_arithmetic":   num_arithmetic,
        "num_union":        num_union,
        "num_always_true":  num_always_true,
    }

# ─── 6. PLOTS ─────────────────────────────────────────────────────────────────

def save_eda_plots(df: pd.DataFrame, y: np.ndarray,
                   X_train_scaled: np.ndarray, y_train: np.ndarray,
                   output_path: str):

    fig, axes = plt.subplots(1, 3, figsize=(16, 5))
    fig.suptitle("SQL Injection Dataset — EDA", fontsize=14, fontweight="bold")

    # Plot 1 — Class distribution
    ax = axes[0]
    labels_str = ["Benign (0)", "Malicious (1)"]
    colors     = ["#3B8BD4", "#D85A30"]
    bar_vals   = [int(np.sum(y == 0)), int(np.sum(y == 1))]
    bars = ax.bar(labels_str, bar_vals, color=colors, edgecolor="white", width=0.5)
    for bar, val in zip(bars, bar_vals):
        ax.text(
            bar.get_x() + bar.get_width() / 2,
            bar.get_height() + 50,
            f"{val:,}", ha="center", va="bottom", fontsize=11
        )
    ax.set_title("Class Distribution")
    ax.set_ylabel("Sample count")
    ax.spines[["top", "right"]].set_visible(False)

    # Plot 2 — Query length histogram
    ax = axes[1]
    for label_val, color, name in [
        (0, "#3B8BD4", "Benign"),
        (1, "#D85A30", "Malicious")
    ]:
        subset = df.loc[df["label"] == label_val, "query_clean"].str.len()
        ax.hist(
            subset.clip(upper=500), bins=50,
            alpha=0.6, color=color, label=name, edgecolor="none"
        )
    ax.set_title("Query Length Distribution")
    ax.set_xlabel("Characters (clipped at 500)")
    ax.set_ylabel("Frequency")
    ax.legend()
    ax.spines[["top", "right"]].set_visible(False)

    # Plot 3 — Feature correlation heatmap
    ax = axes[2]
    corr_df = pd.DataFrame(X_train_scaled, columns=FEATURE_COLS)
    corr_df["label"] = y_train
    corr = corr_df.corr()
    mask = np.triu(np.ones_like(corr, dtype=bool))
    sns.heatmap(
        corr, mask=mask, ax=ax, cmap="coolwarm",
        center=0, linewidths=0.3, annot=True, fmt=".1f",
        annot_kws={"size": 7}, cbar_kws={"shrink": 0.8}
    )
    ax.set_title("Feature Correlation")
    ax.tick_params(labelsize=7)

    plt.tight_layout()
    plt.savefig(output_path, dpi=150, bbox_inches="tight")
    print(f"[PLOT]  EDA plot saved → {output_path}")
    plt.close()

# ─── 7. SAVE SCALER TO model/ ────────────────────────────────────────────────

def save_scaler(scaler: StandardScaler, path: str):
    """Serialize the fitted scaler to model/scaler.pkl using pickle."""
    os.makedirs(os.path.dirname(path), exist_ok=True)
    with open(path, "wb") as f:
        pickle.dump(scaler, f)
    print(f"[MODEL] Scaler saved       → {path}")


def save_metadata(metadata: dict, path: str):
    """Save feature names, scale_pos_weight, and run info to JSON."""
    os.makedirs(os.path.dirname(path), exist_ok=True)
    with open(path, "w") as f:
        json.dump(metadata, f, indent=2)
    print(f"[MODEL] Metadata saved     → {path}")


def load_scaler(path: str) -> StandardScaler:
    """Load the saved scaler from model/scaler.pkl."""
    with open(path, "rb") as f:
        scaler = pickle.load(f)
    print(f"[MODEL] Scaler loaded      ← {path}")
    return scaler

# ─── 8. MAIN PIPELINE ─────────────────────────────────────────────────────────

def run_pipeline(raw_path: str = RAW_DATA_PATH):

    os.makedirs(PROC_DIR,    exist_ok=True)
    os.makedirs(MODEL_DIR,   exist_ok=True)
    os.makedirs(RESULTS_DIR, exist_ok=True)

    print("=" * 60)
    print("  SQL INJECTION — PREPROCESSING PIPELINE")
    print("=" * 60)

    # ── 8.1 Load ──────────────────────────────────────────────────────────────
    df = load_dataset(raw_path)

    before = len(df)
    df = df.dropna(subset=["query", "label"])
    df["query"] = df["query"].astype(str)
    df["label"] = df["label"].astype(int)
    print(f"[CLEAN] Dropped {before - len(df)} null rows")

    before = len(df)
    df = df.drop_duplicates(subset=["query"])
    print(f"[CLEAN] Dropped {before - len(df)} duplicate rows")
    print(f"[CLEAN] Remaining: {len(df):,} rows")

    # ── 8.2 EDA ───────────────────────────────────────────────────────────────
    print("\n[EDA]   Class distribution:")
    counts = df["label"].value_counts().sort_index()
    for lbl, cnt in counts.items():
        name = "Benign   (0)" if lbl == 0 else "Malicious(1)"
        print(f"        {name} → {cnt:,}  ({cnt/len(df)*100:.1f}%)")

    # ── 8.3 Clean strings ─────────────────────────────────────────────────────
    print("\n[CLEAN] Normalizing query strings ...")
    df["query_clean"] = df["query"].apply(clean_query)

    lengths = df["query_clean"].str.len()
    print(f"[EDA]   Query length → min:{lengths.min()}  "
          f"max:{lengths.max()}  "
          f"mean:{lengths.mean():.1f}  "
          f"95th%:{lengths.quantile(0.95):.1f}")

    # ── 8.4 Feature extraction ────────────────────────────────────────────────
    print("\n[FEAT]  Extracting 8 features ...")
    features_df = df["query_clean"].apply(
        lambda q: pd.Series(extract_features(q))
    )
    df = pd.concat([df, features_df], axis=1)

    X = df[FEATURE_COLS].values
    y = df["label"].values

    # ── 8.5 Train / Val / Test split ──────────────────────────────────────────
    print(f"\n[SPLIT] 70% train / 15% val / 15% test  (seed={RANDOM_SEED})")

    X_temp, X_test, y_temp, y_test = train_test_split(
        X, y,
        test_size=TEST_SIZE,
        random_state=RANDOM_SEED,
        stratify=y,
    )
    val_ratio = VAL_SIZE / (1.0 - TEST_SIZE)
    X_train, X_val, y_train, y_val = train_test_split(
        X_temp, y_temp,
        test_size=val_ratio,
        random_state=RANDOM_SEED,
        stratify=y_temp,
    )

    print(f"        Train : {len(X_train):,}")
    print(f"        Val   : {len(X_val):,}")
    print(f"        Test  : {len(X_test):,}")

    # ── 8.6 Class imbalance ───────────────────────────────────────────────────
    neg = int(np.sum(y_train == 0))
    pos = int(np.sum(y_train == 1))
    scale_pos_weight = round(neg / pos, 4)
    print(f"\n[IMB]   Train → Benign:{neg:,}  Malicious:{pos:,}")
    print(f"[IMB]   scale_pos_weight = {scale_pos_weight}")

    # ── 8.7 Fit scaler on train, apply to all splits ──────────────────────────
    print("\n[SCALE] Fitting StandardScaler on training set ...")
    scaler = StandardScaler()
    X_train_scaled = scaler.fit_transform(X_train)
    X_val_scaled   = scaler.transform(X_val)
    X_test_scaled  = scaler.transform(X_test)

    # ── 8.8 Save scaler → model/scaler.pkl ────────────────────────────────────
    save_scaler(scaler, SCALER_PATH)

    # ── 8.9 Save metadata → model/model_metadata.json ─────────────────────────
    metadata = {
        "created_at":        datetime.now().isoformat(),
        "dataset":           os.path.basename(raw_path),
        "total_samples":     len(df),
        "train_samples":     len(X_train),
        "val_samples":       len(X_val),
        "test_samples":      len(X_test),
        "feature_cols":      FEATURE_COLS,
        "scale_pos_weight":  scale_pos_weight,
        "random_seed":       RANDOM_SEED,
        "scaler_path":       "model/scaler.pkl",
        "model_path":        "model/xgboost_model.pkl",
        "scaler_means":      scaler.mean_.tolist(),
        "scaler_stds":       scaler.scale_.tolist(),
    }
    save_metadata(metadata, METADATA_PATH)

    # ── 8.10 Save processed CSVs → data/processed/ ────────────────────────────
    def save_split(X_scaled, y_arr, name):
        out = pd.DataFrame(X_scaled, columns=FEATURE_COLS)
        out["label"] = y_arr
        path = os.path.join(PROC_DIR, f"sqli_{name}.csv")
        out.to_csv(path, index=False)
        print(f"[SAVE]  data/processed/sqli_{name}.csv  ({len(out):,} rows)")

    save_split(X_train_scaled, y_train, "train")
    save_split(X_val_scaled,   y_val,   "val")
    save_split(X_test_scaled,  y_test,  "test")

    # ── 8.11 EDA plots ────────────────────────────────────────────────────────
    save_eda_plots(df, y, X_train_scaled, y_train, EDA_PLOT_PATH)

    # ── 8.12 Summary ──────────────────────────────────────────────────────────
    print("\n" + "=" * 60)
    print("  PREPROCESSING COMPLETE")
    print("=" * 60)
    print(f"  model/scaler.pkl              ← use in train.py + predict.py")
    print(f"  model/model_metadata.json     ← run info + feature names")
    print(f"  data/processed/sqli_train.csv")
    print(f"  data/processed/sqli_val.csv")
    print(f"  data/processed/sqli_test.csv")
    print(f"  results/sqli_eda.png")
    print("=" * 60)
    print(f"\n  Next step → run:  python src/train.py")
    print("=" * 60)

    return {
        "X_train": X_train_scaled,
        "X_val":   X_val_scaled,
        "X_test":  X_test_scaled,
        "y_train": y_train,
        "y_val":   y_val,
        "y_test":  y_test,
        "scaler":  scaler,
        "scale_pos_weight": scale_pos_weight,
        "feature_cols":     FEATURE_COLS,
        "metadata":         metadata,
    }


if __name__ == "__main__":
    run_pipeline()
