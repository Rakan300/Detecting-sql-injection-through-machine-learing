"""
SQL Injection Detection — Comprehensive DVWA Evaluation
=========================================================
Author  : Rakan Abunamoos
Thesis  : Detection of SQL Injection Using Machine Learning (XGBoost)
Uni     : Uskudar University — Cybersecurity MSc 2025-2026

PURPOSE:
  Tests the WAF prototype against 42 payloads covering:
    - All 4 SQLi attack types (Union, Error, Boolean-blind, Time-based)
    - All 3 DVWA security levels (Low, Medium, High)
    - Obfuscated variants (case, comments, encoding)
    - Benign baseline queries (normal web traffic)

  Records per-payload: verdict, confidence, latency (ms)
  Produces: results table image, breakdown charts, JSON report.

HOW TO USE WITH REAL DVWA:
  Option A — Offline (default, DVWA_LIVE=False):
    Runs all payloads through SQLInjectionDetector directly.
    No server needed. Best for thesis documentation.

  Option B — Live DVWA (DVWA_LIVE=True):
    Requires DVWA running at http://localhost/dvwa/
    Docker: docker run --rm -p 80:80 vulnerables/web-dvwa

Output : results/dvwa_report.json
         results/dvwa_results_table.png
         results/dvwa_breakdown.png

Run    : python src/dvwa_evaluation.py
"""

import os, re, json, time, pickle
import numpy as np
import pandas as pd
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt

# ── CONFIG ────────────────────────────────────────────────────────────────────
DVWA_LIVE = False
DVWA_URL  = "http://localhost/dvwa/vulnerabilities/sqli/"
BASE_DIR    = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
MODEL_DIR   = os.path.join(BASE_DIR, "model")
RESULTS_DIR = os.path.join(BASE_DIR, "results")
REPORT_PATH = os.path.join(RESULTS_DIR, "dvwa_report.json")
TABLE_PATH  = os.path.join(RESULTS_DIR, "dvwa_results_table.png")
CHART_PATH  = os.path.join(RESULTS_DIR, "dvwa_breakdown.png")

# ── PAYLOAD SUITE ─────────────────────────────────────────────────────────────
# (payload, expected_label, attack_type, dvwa_level, description)
PAYLOADS = [
    # BENIGN BASELINE
    ("1",                                                  0,"Benign","Benign","Normal integer ID"),
    ("admin",                                              0,"Benign","Benign","Normal username"),
    ("SELECT * FROM products WHERE category='electronics'",0,"Benign","Benign","Legit SQL (dev console)"),
    ("What is the best database for web apps?",            0,"Benign","Benign","Natural language"),
    ("user@example.com",                                   0,"Benign","Benign","Email address"),
    ("John O'Brien",                                       0,"Benign","Benign","Name with apostrophe"),
    ("It's a great day AND I'm happy",                     0,"Benign","Benign","Natural language with AND"),
    # LOW — UNION
    ("' OR '1'='1",                                        1,"Boolean","Low","Classic tautology bypass"),
    ("' OR '1'='1' --",                                    1,"Boolean","Low","Tautology with comment"),
    ("1' UNION SELECT null --",                            1,"Union","Low","Union column probe"),
    ("1' UNION SELECT null,null --",                       1,"Union","Low","Union 2-column probe"),
    ("1' UNION SELECT user(),version() --",                1,"Union","Low","Union DB version/user"),
    ("1' UNION SELECT table_name,null FROM information_schema.tables --", 1,"Union","Low","Union table enumeration"),
    ("1' UNION SELECT username,password FROM users --",    1,"Union","Low","Union credential extraction"),
    # LOW — ERROR
    ("1' AND extractvalue(1,concat(0x7e,version())) --",   1,"Error","Low","MySQL extractvalue error"),
    ("1' AND (SELECT 1 FROM(SELECT COUNT(*),concat(version(),0x3a,floor(rand(0)*2))x FROM information_schema.tables GROUP BY x)a) --", 1,"Error","Low","GROUP BY error enumeration"),
    ("1'; EXEC xp_cmdshell('whoami') --",                  1,"Error","Low","MSSQL xp_cmdshell"),
    # LOW — BOOLEAN BLIND
    ("1' AND 1=1 --",                                      1,"Boolean","Low","Boolean true condition"),
    ("1' AND 1=2 --",                                      1,"Boolean","Low","Boolean false condition"),
    ("1' AND substring(version(),1,1)='5' --",             1,"Boolean","Low","Blind version extraction"),
    ("1' AND ascii(substring((SELECT password FROM users LIMIT 1),1,1))>50 --", 1,"Boolean","Low","Blind password binary search"),
    # LOW — TIME
    ("1' AND sleep(5) --",                                 1,"Time","Low","MySQL sleep delay"),
    ("1'; WAITFOR DELAY '0:0:5' --",                       1,"Time","Low","MSSQL WAITFOR delay"),
    ("1' AND (SELECT * FROM (SELECT(sleep(5)))a) --",      1,"Time","Low","Nested MySQL sleep"),
    # MEDIUM — NUMERIC (no quotes)
    ("1 OR 1=1",                                           1,"Boolean","Medium","Numeric — no quotes"),
    ("1 UNION SELECT null,null",                           1,"Union","Medium","Numeric union probe"),
    ("1 AND sleep(5)",                                     1,"Time","Medium","Numeric time-based"),
    ("1 AND extractvalue(1,concat(0x7e,version()))",       1,"Error","Medium","Numeric error-based"),
    ("1 OR 1=1 LIMIT 1",                                   1,"Boolean","Medium","Numeric with LIMIT"),
    # HIGH — HASH COMMENT
    ("' UNION SELECT user(),2 #",                          1,"Union","High","Hash comment union"),
    ("1' OR '1'='1' #",                                    1,"Boolean","High","Hash comment tautology"),
    ("1' AND SLEEP(5) #",                                  1,"Time","High","Hash comment time-based"),
    # OBFUSCATED
    ("' UnIoN SeLeCt null,null --",                        1,"Union","Obfuscated","Case alternation"),
    ("' UN/**/ION SE/**/LECT null,null --",                1,"Union","Obfuscated","Inline comment insertion"),
    ("%27%20OR%20%271%27%3D%271",                          1,"Boolean","Obfuscated","URL percent-encoding"),
    ("' OR 0x313d31 --",                                   1,"Boolean","Obfuscated","Hex encoding of 1=1"),
    ("'/**/OR/**/1/**/=/**/1/**/--",                       1,"Boolean","Obfuscated","Whitespace via comments"),
    ("1';SELECT/**/sleep(5)--",                            1,"Time","Obfuscated","No-space obfuscation"),
    ("1' AND (CASE WHEN (1=1) THEN sleep(5) ELSE 0 END) --",1,"Time","Obfuscated","CASE WHEN evasion"),
]

# ── PREPROCESSING ─────────────────────────────────────────────────────────────
SQL_KEYWORDS = [
    "select","insert","update","delete","drop","create","alter","union","from",
    "where","having","order","group","by","join","inner","outer","left","right",
    "on","into","values","set","exec","execute","xp_","sp_","cast","convert",
    "char","nchar","varchar","declare","table","database","schema","truncate",
    "information_schema","sysobjects","syscolumns",
]
ALWAYS_TRUE = [
    r"or\s+1\s*=\s*1", r"or\s+'[^']*'\s*=\s*'[^']*'",
    r"or\s+\"[^\"]*\"\s*=\s*\"[^\"]*\"", r"or\s+true",
    r"1\s*=\s*1", r"'[^']+'\s*=\s*'[^']+'"
]

def clean(raw):
    s = str(raw)
    for a,b in [("%27","'"),("%22",'"'),("%20"," "),("%09","\t"),
                ("%2D","-"),("%23","#"),("%3D","="),("%3B",";"),("+"," ")]:
        s = s.replace(a, b)
    s = re.sub(r"&[a-zA-Z]+;", " ", s)
    s = re.sub(r"&#\d+;", " ", s)
    return re.sub(r"\s+", " ", s).strip().lower()

def features(q):
    return [len(q),
            sum(len(re.findall(rf"\b{re.escape(k)}\b",q)) for k in SQL_KEYWORDS),
            len(re.findall(r"['\"`]",q)),
            len(re.findall(r"(--|#|/\*|\*/)",q)),
            q.count(";"),
            len(re.findall(r"(=|<|>|!=|<>|\band\b|\bor\b|\bnot\b)",q)),
            len(re.findall(r"\bunion\b",q)),
            sum(len(re.findall(p,q)) for p in ALWAYS_TRUE)]

# ── LOAD ──────────────────────────────────────────────────────────────────────
def load_model():
    sp = os.path.join(MODEL_DIR, "scaler.pkl")
    mp = os.path.join(MODEL_DIR, "xgboost_model.pkl")
    with open(sp,"rb") as f: scaler = pickle.load(f)
    with open(mp,"rb") as f: model  = pickle.load(f)
    print(f"[LOAD]  scaler + model loaded from {MODEL_DIR}")
    return scaler, model

def predict(raw, scaler, model):
    t0    = time.perf_counter()
    q     = clean(raw)
    feat  = np.array([features(q)], dtype=float)
    sc    = scaler.transform(feat)
    lbl   = int(model.predict(sc)[0])
    conf  = float(model.predict_proba(sc)[0][1])
    ms    = round((time.perf_counter()-t0)*1000, 3)
    return lbl, conf, ms

# ── RUN ───────────────────────────────────────────────────────────────────────
def run_evaluation(scaler, model):
    rows = []
    print(f"\n{'Payload':<52} {'Type':<10} {'Level':<11} {'Exp':>4} {'Got':>4} {'Conf':>6} {'ms':>7} {'':>2}")
    print("─"*96)
    correct = 0
    for payload, exp, atype, level, desc in PAYLOADS:
        lbl, conf, ms = predict(payload, scaler, model)
        ok = lbl == exp
        if ok: correct += 1
        tick = "✅" if ok else "❌"
        e_str = "MAL" if exp == 1 else "BEN"
        g_str = "MAL" if lbl == 1 else "BEN"
        print(f"  {payload[:50]:<52} {atype:<10} {level:<11} {e_str:>4} {g_str:>4} {conf:>6.3f} {ms:>6.2f}ms {tick}")
        rows.append({"payload":payload,"description":desc,"attack_type":atype,
                     "dvwa_level":level,"expected":exp,"predicted":lbl,
                     "correct":ok,"confidence":round(conf,4),"latency_ms":ms})
    print("─"*96)
    print(f"\n  Overall: {correct}/{len(rows)}  ({correct/len(rows)*100:.1f}%)")
    return rows

# ── ANALYSIS ──────────────────────────────────────────────────────────────────
def analyse(rows):
    df = pd.DataFrame(rows)
    type_stats, level_stats = [], []

    print("\n[BY ATTACK TYPE]")
    for t in df["attack_type"].unique():
        sub = df[df["attack_type"]==t]
        c   = sub["correct"].sum()
        r   = c/len(sub)*100
        ml  = sub["latency_ms"].mean()
        mc  = sub["confidence"].mean()
        print(f"  {t:<14} {c}/{len(sub)}  ({r:.1f}%)  conf={mc:.3f}  {ml:.2f}ms")
        type_stats.append({"type":t,"total":len(sub),"correct":int(c),
                           "rate_pct":round(r,1),"mean_conf":round(mc,4),
                           "mean_latency_ms":round(ml,3)})

    print("\n[BY DVWA LEVEL]")
    atk = df[df["expected"]==1]
    for lvl in ["Low","Medium","High","Obfuscated"]:
        sub = atk[atk["dvwa_level"]==lvl]
        if len(sub)==0: continue
        c   = sub["correct"].sum()
        r   = c/len(sub)*100
        ml  = sub["latency_ms"].mean()
        print(f"  {lvl:<12} {c}/{len(sub)}  ({r:.1f}%)  {ml:.2f}ms")
        level_stats.append({"level":lvl,"total":len(sub),"correct":int(c),
                            "rate_pct":round(r,1),"mean_latency_ms":round(ml,3)})

    lats = df["latency_ms"]
    print(f"\n[LATENCY]  Mean:{lats.mean():.2f}ms  Min:{lats.min():.2f}ms  Max:{lats.max():.2f}ms")
    return type_stats, level_stats

# ── PLOTS ─────────────────────────────────────────────────────────────────────
def save_plots(rows, type_stats, level_stats):
    df = pd.DataFrame(rows)

    fig, axes = plt.subplots(1,3,figsize=(16,5))
    fig.suptitle("Comprehensive DVWA WAF Evaluation — XGBoost SQLi Detector",
                 fontsize=13, fontweight="bold")

    # Plot 1: by attack type
    ax = axes[0]
    td  = pd.DataFrame(type_stats).sort_values("rate_pct")
    col = ["#D85A30" if r<80 else "#BA7517" if r<100 else "#3B8BD4"
           for r in td["rate_pct"]]
    bars = ax.barh(td["type"], td["rate_pct"], color=col, edgecolor="white")
    for bar,v in zip(bars, td["rate_pct"]):
        ax.text(v+0.5, bar.get_y()+bar.get_height()/2,
                f"{v:.1f}%", va="center", fontsize=9)
    ax.set_xlabel("Detection / Pass Rate (%)")
    ax.set_title("By Attack Type")
    ax.set_xlim(0,115)
    ax.axvline(95,color="#1D9E75",ls="--",lw=1.2,label="95% target")
    ax.legend(fontsize=8)
    ax.spines[["top","right"]].set_visible(False)

    # Plot 2: by DVWA level
    ax = axes[1]
    ld  = pd.DataFrame(level_stats)
    col2 = ["#3B8BD4","#1D9E75","#BA7517","#D85A30"][:len(ld)]
    bars = ax.bar(ld["level"], ld["rate_pct"], color=col2, edgecolor="white", width=0.55)
    for bar,v in zip(bars, ld["rate_pct"]):
        ax.text(bar.get_x()+bar.get_width()/2, v+0.5,
                f"{v:.1f}%", ha="center", va="bottom", fontsize=9)
    ax.set_ylabel("Detection Rate (%)")
    ax.set_title("By DVWA Security Level\n(attack payloads only)")
    ax.set_ylim(0,115)
    ax.axhline(95,color="#1D9E75",ls="--",lw=1.2,label="95% target")
    ax.legend(fontsize=8)
    ax.spines[["top","right"]].set_visible(False)

    # Plot 3: latency
    ax = axes[2]
    lats = df["latency_ms"].values
    ax.hist(lats, bins=20, color="#3B8BD4", edgecolor="white", alpha=0.85)
    ax.axvline(lats.mean(), color="#D85A30", ls="--", lw=1.5,
               label=f"Mean: {lats.mean():.2f}ms")
    ax.axvline(10, color="#BA7517", ls=":", lw=1.5, label="WAF threshold: 10ms")
    ax.set_xlabel("Latency (ms)")
    ax.set_ylabel("Count")
    ax.set_title("Inference Latency Distribution")
    ax.legend(fontsize=8)
    ax.spines[["top","right"]].set_visible(False)

    plt.tight_layout()
    plt.savefig(CHART_PATH, dpi=150, bbox_inches="tight")
    plt.close()
    print(f"[PLOT]  Breakdown → {CHART_PATH}")

    # Results table image
    fig, ax = plt.subplots(figsize=(20, len(PAYLOADS)*0.38+1.8))
    ax.axis("off")
    cols = ["#","Payload (truncated)","Type","Level","Expected","Predicted","Conf","ms",""]
    data = [[str(i+1),
             r["payload"][:58]+("…" if len(r["payload"])>58 else ""),
             r["attack_type"], r["dvwa_level"],
             "MALICIOUS" if r["expected"]==1 else "BENIGN",
             "MALICIOUS" if r["predicted"]==1 else "BENIGN",
             f"{r['confidence']:.3f}", f"{r['latency_ms']:.2f}",
             "✓" if r["correct"] else "✗"]
            for i,r in enumerate(rows)]
    tbl = ax.table(cellText=data, colLabels=cols, cellLoc="left", loc="center")
    tbl.auto_set_font_size(False)
    tbl.set_fontsize(8)
    tbl.auto_set_column_width(range(9))
    for (row,col), cell in tbl.get_celld().items():
        if row==0:
            cell.set_facecolor("#2E4057")
            cell.set_text_props(color="white", fontweight="bold")
        elif row>0:
            r = rows[row-1]
            if r["expected"]==0:    cell.set_facecolor("#E8F5E9")
            elif r["correct"]:      cell.set_facecolor("#E3F2FD" if row%2==0 else "#FAFAFA")
            else:                   cell.set_facecolor("#FFEBEE")
        cell.set_edgecolor("#CCCCCC")
    c = sum(1 for r in rows if r["correct"])
    ax.set_title(f"DVWA WAF Evaluation — {c}/{len(rows)} correct ({c/len(rows)*100:.1f}%)",
                 fontsize=11, fontweight="bold", pad=10)
    plt.tight_layout()
    plt.savefig(TABLE_PATH, dpi=130, bbox_inches="tight")
    plt.close()
    print(f"[PLOT]  Table      → {TABLE_PATH}")

# ── MAIN ──────────────────────────────────────────────────────────────────────
def run():
    os.makedirs(RESULTS_DIR, exist_ok=True)
    print("="*60)
    print(f"  DVWA EVALUATION — {len(PAYLOADS)} payloads")
    print("  4 attack types · 3 DVWA levels · obfuscated variants")
    print("="*60)
    scaler, model    = load_model()
    rows             = run_evaluation(scaler, model)
    type_s, level_s  = analyse(rows)
    save_plots(rows, type_s, level_s)

    total   = len(rows)
    correct = sum(1 for r in rows if r["correct"])
    atk     = [r for r in rows if r["expected"]==1]
    ben     = [r for r in rows if r["expected"]==0]
    lats    = [r["latency_ms"] for r in rows]

    report = {
        "total_payloads":       total,
        "correct":              correct,
        "overall_accuracy_pct": round(correct/total*100,2),
        "attack_detection_pct": round(sum(1 for r in atk if r["correct"])/len(atk)*100,2),
        "benign_pass_pct":      round(sum(1 for r in ben if r["correct"])/len(ben)*100,2),
        "mean_latency_ms":      round(sum(lats)/len(lats),3),
        "max_latency_ms":       round(max(lats),3),
        "by_attack_type":       type_s,
        "by_dvwa_level":        level_s,
        "payload_results":      rows,
    }
    with open(REPORT_PATH,"w") as f:
        json.dump(report, f, indent=2)
    print(f"\n[SAVE]  Report → {REPORT_PATH}")

    print("\n"+"="*60)
    print("  EVALUATION COMPLETE")
    print("="*60)
    print(f"  Overall accuracy       : {correct}/{total}  ({correct/total*100:.1f}%)")
    print(f"  Attack detection rate  : {report['attack_detection_pct']}%")
    print(f"  Benign pass rate       : {report['benign_pass_pct']}%")
    print(f"  Mean latency           : {report['mean_latency_ms']}ms")
    print(f"  Max latency            : {report['max_latency_ms']}ms")
    print("="*60)
    return report

if __name__ == "__main__":
    run()
