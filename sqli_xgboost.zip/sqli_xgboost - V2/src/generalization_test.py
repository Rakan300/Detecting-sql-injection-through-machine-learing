"""
SQL Injection Detection — Generalization Test
==============================================
Author  : Rakan Abunamoos
Thesis  : Detection of SQL Injection Using Machine Learning (XGBoost)
Uni     : Uskudar University — Cybersecurity MSc 2025-2026

PURPOSE:
  Tests the trained XGBoost model on the libinjection dataset —
  a completely different source of SQL injection payloads never
  seen during training. This replicates the generalization
  methodology of Hosam et al. (2021), who reported 87.3% accuracy
  under the same train-on-Kaggle / test-on-libinjection conditions.

HOW TO GET THE LIBINJECTION FILES:
  1. Go to: https://github.com/client9/libinjection/tree/master/data
  2. Download ALL files that start with "sqli-" (there are ~30 of them)
     Example files:
       sqli-hackers.txt
       sqli-sqlmap.txt
       sqli-arithmetic_blind_sqli.txt
       sqli-arneswinnen.net-boolean.txt
       sqli-arneswinnen.net-time.txt
       ... (download all sqli-*.txt files)
  3. Also download: false_positives.txt  (used for false positive testing)
  4. Place ALL of them in:  data/generalization/

  Each file is plain text — one SQL injection payload per line.
  Lines starting with # are comments and are skipped automatically.

WHAT THIS SCRIPT DOES:
  Phase 1 — Attack detection test (Recall)
    Loads all sqli-*.txt files → labels them malicious (1)
    Runs model → measures detection rate
    Compares with Hosam et al. (2021) benchmark of 87.3%

  Phase 2 — False positive test (Precision)
    Loads false_positives.txt → labels them benign (0)
    Runs model → measures false positive rate
    (How often does the model wrongly block legitimate queries?)

OUTPUT:
  results/generalization_report.json
  results/generalization_results.png
  Console: full breakdown by file + comparison with Hosam et al.

Run   : python src/generalization_test.py
"""

import os
import re
import json
import pickle
import numpy as np
import pandas as pd
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt

# ─── 0. PATHS ─────────────────────────────────────────────────────────────────

BASE_DIR      = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
MODEL_DIR     = os.path.join(BASE_DIR, "model")
RESULTS_DIR   = os.path.join(BASE_DIR, "results")
GEN_DIR       = os.path.join(BASE_DIR, "data", "generalization")

SCALER_PATH   = os.path.join(MODEL_DIR,   "scaler.pkl")
MODEL_PATH    = os.path.join(MODEL_DIR,   "xgboost_model.pkl")
METADATA_PATH = os.path.join(MODEL_DIR,   "model_metadata.json")
REPORT_PATH   = os.path.join(RESULTS_DIR, "generalization_report.json")
PLOT_PATH     = os.path.join(RESULTS_DIR, "generalization_results.png")

# Hosam et al. (2021) benchmark — same train/test methodology
HOSAM_BENCHMARK = 87.30
KAGGLE_F1       = 98.77   # your evaluate.py result

# ─── 1. SQL PATTERNS (must match preprocessing.py exactly) ────────────────────

SQL_KEYWORDS = [
    "select", "insert", "update", "delete", "drop", "create", "alter",
    "union", "from", "where", "having", "order", "group", "by", "join",
    "inner", "outer", "left", "right", "on", "into", "values", "set",
    "exec", "execute", "xp_", "sp_", "cast", "convert", "char", "nchar",
    "varchar", "declare", "table", "database", "schema", "truncate",
    "information_schema", "sysobjects", "syscolumns",
]

ALWAYS_TRUE_PATTERNS = [
    r"or\s+1\s*=\s*1",
    r"or\s+'[^']*'\s*=\s*'[^']*'",
    r"or\s+\"[^\"]*\"\s*=\s*\"[^\"]*\"",
    r"or\s+true",
    r"1\s*=\s*1",
    r"'[^']+'\s*=\s*'[^']+'",
]

# ─── 2. PREPROCESSING (mirrors preprocessing.py exactly) ──────────────────────

def clean_query(raw: str) -> str:
    if not isinstance(raw, str):
        return ""
    s = raw
    s = s.replace("%27", "'").replace("%22", '"')
    s = s.replace("%20", " ").replace("%09", "\t")
    s = s.replace("%2D", "-").replace("%23", "#")
    s = s.replace("%3D", "=").replace("%3B", ";")
    s = s.replace("+", " ")
    s = re.sub(r"&[a-zA-Z]+;", " ", s)
    s = re.sub(r"&#\d+;",      " ", s)
    s = re.sub(r"\s+",         " ", s).strip()
    s = s.lower()
    return s


def extract_features(query: str) -> list:
    q = query
    return [
        len(q),
        sum(len(re.findall(rf"\b{re.escape(kw)}\b", q)) for kw in SQL_KEYWORDS),
        len(re.findall(r"['\"`]", q)),
        len(re.findall(r"(--|#|/\*|\*/)", q)),
        q.count(";"),
        len(re.findall(r"(=|<|>|!=|<>|\band\b|\bor\b|\bnot\b)", q)),
        len(re.findall(r"\bunion\b", q)),
        sum(len(re.findall(p, q)) for p in ALWAYS_TRUE_PATTERNS),
    ]

# ─── 3. LOAD MODEL + SCALER ───────────────────────────────────────────────────

def load_artifacts():
    for path, name in [(SCALER_PATH, "scaler"), (MODEL_PATH, "model")]:
        if not os.path.exists(path):
            raise FileNotFoundError(
                f"{name} not found at {path}\n"
                f"Run preprocessing.py and train.py first."
            )
    with open(SCALER_PATH, "rb") as f:
        scaler = pickle.load(f)
    with open(MODEL_PATH, "rb") as f:
        model  = pickle.load(f)
    with open(METADATA_PATH) as f:
        meta   = json.load(f)
    print(f"[LOAD]  Scaler ← {SCALER_PATH}")
    print(f"[LOAD]  Model  ← {MODEL_PATH}")
    return scaler, model, meta

# ─── 4. LOAD LIBINJECTION FILES ───────────────────────────────────────────────

def load_libinjection_files(gen_dir: str) -> tuple:
    """
    Loads all sqli-*.txt files from the generalization directory.
    Also loads false_positives.txt if present.
    Returns:
        attack_df   — all malicious payloads (label=1)
        fp_df       — false positive queries  (label=0), or None
        file_counts — dict of {filename: count} for reporting
    """
    if not os.path.exists(gen_dir):
        os.makedirs(gen_dir, exist_ok=True)

    # Find all sqli-*.txt files
    sqli_files = sorted([
        f for f in os.listdir(gen_dir)
        if f.startswith("sqli-") and f.endswith(".txt")
    ])

    if not sqli_files:
        raise FileNotFoundError(
            f"\n[ERROR] No sqli-*.txt files found in: {gen_dir}\n"
            f"\nTo download the libinjection dataset:\n"
            f"  1. Go to: https://github.com/client9/libinjection/tree/master/data\n"
            f"  2. Download all files starting with 'sqli-'\n"
            f"  3. Place them in: {gen_dir}\n"
            f"\nQuick download with curl (run from your project root):\n"
            f"  For each file, run:\n"
            f"  curl -o data/generalization/sqli-hackers.txt \\\n"
            f"    https://raw.githubusercontent.com/client9/libinjection/master/data/sqli-hackers.txt\n"
        )

    all_rows   = []
    file_counts = {}

    for fname in sqli_files:
        path = os.path.join(gen_dir, fname)
        with open(path, "r", encoding="utf-8", errors="ignore") as f:
            lines = [l.strip() for l in f if l.strip() and not l.startswith("#")]
        file_counts[fname] = len(lines)
        for line in lines:
            all_rows.append({"query": line, "label": 1, "source": fname})

    attack_df = pd.DataFrame(all_rows)

    # Drop duplicates across all files
    before = len(attack_df)
    attack_df = attack_df.drop_duplicates(subset=["query"])
    dupes_removed = before - len(attack_df)

    print(f"\n[LOAD]  Loaded {len(sqli_files)} sqli-*.txt files")
    print(f"[LOAD]  Total payloads : {before:,}")
    print(f"[LOAD]  Duplicates     : {dupes_removed:,} removed")
    print(f"[LOAD]  Unique payloads: {len(attack_df):,}")

    # Load false_positives.txt if available
    fp_path = os.path.join(gen_dir, "false_positives.txt")
    fp_df   = None
    if os.path.exists(fp_path):
        with open(fp_path, "r", encoding="utf-8", errors="ignore") as f:
            fp_lines = [l.strip() for l in f if l.strip() and not l.startswith("#")]
        fp_df = pd.DataFrame({"query": fp_lines, "label": 0, "source": "false_positives.txt"})
        fp_df = fp_df.drop_duplicates(subset=["query"])
        print(f"[LOAD]  false_positives.txt: {len(fp_df):,} benign queries loaded")
    else:
        print(f"[LOAD]  false_positives.txt: not found (skipping FP test)")

    return attack_df, fp_df, file_counts

# ─── 5. BUILD FEATURES ────────────────────────────────────────────────────────

def build_features(df: pd.DataFrame, scaler) -> tuple:
    df = df.copy()
    df["query_clean"] = df["query"].apply(clean_query)
    X_raw    = np.array([extract_features(q) for q in df["query_clean"]], dtype=float)
    X_scaled = scaler.transform(X_raw)   # use saved scaler — never refit
    return X_scaled, df

# ─── 6. EVALUATE ──────────────────────────────────────────────────────────────

def evaluate_attacks(model, X, df) -> dict:
    """Phase 1: Detection rate on attack payloads."""
    y_pred = model.predict(X)
    y_prob = model.predict_proba(X)[:, 1]

    detected  = int(np.sum(y_pred == 1))
    missed    = int(np.sum(y_pred == 0))
    total     = len(y_pred)
    det_rate  = detected / total

    print("\n" + "─" * 55)
    print("  PHASE 1 — ATTACK DETECTION (Recall on unseen attacks)")
    print("─" * 55)
    print(f"  Total payloads tested : {total:,}")
    print(f"  Detected (TP)         : {detected:,}  ({det_rate*100:.2f}%)")
    print(f"  Missed   (FN)         : {missed:,}  ({(1-det_rate)*100:.2f}%)")
    print(f"  Detection Rate        : {det_rate:.4f}  ({det_rate*100:.2f}%)")
    print("─" * 55)
    print(f"  Hosam et al. (2021)   : 87.30%  [Logistic Regression]")
    diff = det_rate*100 - HOSAM_BENCHMARK
    arrow = "▲" if diff >= 0 else "▼"
    print(f"  This thesis (XGBoost) : {det_rate*100:.2f}%  [{arrow} {abs(diff):.2f} pp vs benchmark]")
    print("─" * 55)

    # Per-file breakdown
    print("\n[BREAKDOWN] Detection rate per source file:")
    df_results = df.copy()
    df_results["predicted"] = y_pred
    per_file = (
        df_results.groupby("source")
        .apply(lambda g: pd.Series({
            "total":    len(g),
            "detected": (g["predicted"] == 1).sum(),
            "rate_pct": round((g["predicted"] == 1).mean() * 100, 1)
        }))
        .reset_index()
        .sort_values("rate_pct")
    )
    print(f"  {'File':<45} {'Total':>6} {'Detected':>9} {'Rate':>7}")
    print(f"  {'─'*45} {'─'*6} {'─'*9} {'─'*7}")
    for _, row in per_file.iterrows():
        flag = " ⚠" if row["rate_pct"] < 80 else ""
        print(f"  {row['source']:<45} {int(row['total']):>6} "
              f"{int(row['detected']):>9} {row['rate_pct']:>6.1f}%{flag}")

    # Missed payload samples
    missed_df = df_results[df_results["predicted"] == 0]
    if len(missed_df) > 0:
        print(f"\n[ANALYSIS] Sample missed payloads ({min(10, len(missed_df))} of {len(missed_df)}):")
        for _, row in missed_df.head(10).iterrows():
            conf = y_prob[df_results.index.get_loc(row.name)]
            print(f"  [conf={conf:.3f}] {row['query'][:75]}")

    return {
        "total_payloads":    total,
        "detected":          detected,
        "missed":            missed,
        "detection_rate":    round(det_rate, 4),
        "detection_pct":     round(det_rate * 100, 2),
        "hosam_benchmark":   HOSAM_BENCHMARK,
        "delta_vs_hosam_pp": round(det_rate*100 - HOSAM_BENCHMARK, 2),
        "per_file":          per_file.to_dict(orient="records"),
    }


def evaluate_false_positives(model, X, df) -> dict:
    """Phase 2: False positive rate on benign queries."""
    y_pred = model.predict(X)
    total      = len(y_pred)
    fp_count   = int(np.sum(y_pred == 1))  # benign wrongly flagged as malicious
    tn_count   = int(np.sum(y_pred == 0))
    fp_rate    = fp_count / total

    print("\n" + "─" * 55)
    print("  PHASE 2 — FALSE POSITIVE TEST (on false_positives.txt)")
    print("─" * 55)
    print(f"  Total benign queries  : {total:,}")
    print(f"  Correctly passed (TN) : {tn_count:,}  ({(1-fp_rate)*100:.2f}%)")
    print(f"  Wrongly blocked (FP)  : {fp_count:,}  ({fp_rate*100:.2f}%)")
    print("─" * 55)

    # Show falsely blocked queries
    if fp_count > 0:
        fp_df = df[y_pred == 1]
        print(f"\n[FP ANALYSIS] Queries incorrectly blocked:")
        for _, row in fp_df.head(10).iterrows():
            print(f"  → {row['query'][:75]}")

    return {
        "total_benign":       total,
        "true_negatives":     tn_count,
        "false_positives":    fp_count,
        "false_positive_rate": round(fp_rate, 4),
        "false_positive_pct": round(fp_rate * 100, 2),
    }

# ─── 7. PLOT ──────────────────────────────────────────────────────────────────

def save_plot(attack_results: dict, fp_results: dict, output_path: str):
    has_fp = fp_results is not None
    ncols  = 3 if has_fp else 2
    fig, axes = plt.subplots(1, ncols, figsize=(6*ncols, 5))
    fig.suptitle("Generalization Test — libinjection vs. Kaggle Training Set",
                 fontsize=13, fontweight="bold")

    # ── Plot 1: Detected vs Missed ───────────────────────────────────────────
    ax = axes[0]
    vals   = [attack_results["detected"], attack_results["missed"]]
    labels = ["Detected\n(TP)", "Missed\n(FN)"]
    colors = ["#3B8BD4", "#D85A30"]
    bars   = ax.bar(labels, vals, color=colors, edgecolor="white", width=0.5)
    for bar, v in zip(bars, vals):
        ax.text(bar.get_x() + bar.get_width()/2,
                bar.get_height() + max(vals)*0.01,
                f"{v:,}", ha="center", va="bottom", fontsize=11)
    ax.set_title("Attack Detection on libinjection", fontsize=11)
    ax.set_ylabel("Payload count")
    ax.spines[["top", "right"]].set_visible(False)
    ax.text(0.5, 0.97,
            f"Detection Rate: {attack_results['detection_pct']}%",
            ha="center", va="top", transform=ax.transAxes,
            fontsize=12, fontweight="bold", color="#3B8BD4")

    # ── Plot 2: Benchmark comparison ─────────────────────────────────────────
    ax = axes[1]
    names  = ["Hosam\n(2021)\nLogistic Reg.", "This Thesis\nXGBoost"]
    values = [HOSAM_BENCHMARK, attack_results["detection_pct"]]
    bcolors = ["#AAAAAA", "#3B8BD4"]
    bars   = ax.bar(names, values, color=bcolors, edgecolor="white", width=0.5)
    for bar, v in zip(bars, values):
        ax.text(bar.get_x() + bar.get_width()/2,
                v + 0.5, f"{v:.2f}%",
                ha="center", va="bottom", fontsize=11)
    ax.set_title("Generalization vs. Literature Benchmark", fontsize=11)
    ax.set_ylabel("Detection Rate on Unseen Data (%)")
    ax.set_ylim(0, 110)
    ax.axhline(95, color="#1D9E75", ls="--", lw=1.2, label="95% target")
    ax.legend(fontsize=9)
    ax.spines[["top", "right"]].set_visible(False)

    # ── Plot 3 (optional): False positive rate ────────────────────────────────
    if has_fp and ncols == 3:
        ax = axes[2]
        fp_vals   = [fp_results["true_negatives"], fp_results["false_positives"]]
        fp_labels = ["Correctly\nPassed (TN)", "Wrongly\nBlocked (FP)"]
        fp_colors = ["#3B8BD4", "#D85A30"]
        bars = ax.bar(fp_labels, fp_vals, color=fp_colors, edgecolor="white", width=0.5)
        for bar, v in zip(bars, fp_vals):
            ax.text(bar.get_x() + bar.get_width()/2,
                    bar.get_height() + max(fp_vals)*0.01,
                    f"{v:,}", ha="center", va="bottom", fontsize=11)
        ax.set_title("False Positive Test\n(false_positives.txt)", fontsize=11)
        ax.set_ylabel("Query count")
        ax.spines[["top", "right"]].set_visible(False)
        ax.text(0.5, 0.97,
                f"FP Rate: {fp_results['false_positive_pct']}%",
                ha="center", va="top", transform=ax.transAxes,
                fontsize=12, fontweight="bold", color="#D85A30")

    plt.tight_layout()
    plt.savefig(output_path, dpi=150, bbox_inches="tight")
    plt.close()
    print(f"\n[PLOT]  Saved → {output_path}")

# ─── 8. MAIN ──────────────────────────────────────────────────────────────────

def run_generalization_test():
    os.makedirs(GEN_DIR,     exist_ok=True)
    os.makedirs(RESULTS_DIR, exist_ok=True)

    print("=" * 55)
    print("  SQL INJECTION — GENERALIZATION TEST")
    print("  Train : Kaggle SQLi Dataset")
    print("  Test  : libinjection (unseen distribution)")
    print("=" * 55)

    # Load artifacts
    scaler, model, meta = load_artifacts()

    # Load libinjection files
    attack_df, fp_df, file_counts = load_libinjection_files(GEN_DIR)

    # Phase 1: Attack detection
    X_attack, attack_df = build_features(attack_df, scaler)
    attack_results = evaluate_attacks(model, X_attack, attack_df)

    # Phase 2: False positives (if file exists)
    fp_results = None
    if fp_df is not None:
        X_fp, fp_df = build_features(fp_df, scaler)
        fp_results  = evaluate_false_positives(model, X_fp, fp_df)

    # Save plot
    save_plot(attack_results, fp_results, PLOT_PATH)

    # Save report
    report = {
        "attack_detection": attack_results,
        "false_positives":  fp_results,
        "kaggle_f1_pct":    KAGGLE_F1,
        "hosam_benchmark":  HOSAM_BENCHMARK,
    }
    with open(REPORT_PATH, "w") as f:
        json.dump(report, f, indent=2)
    print(f"[SAVE]  Report → {REPORT_PATH}")

    # Final summary
    print("\n" + "=" * 55)
    print("  GENERALIZATION TEST COMPLETE")
    print("=" * 55)
    print(f"  Kaggle test F1          : {KAGGLE_F1}%  (same distribution)")
    print(f"  libinjection detection  : {attack_results['detection_pct']}%  (unseen distribution)")
    print(f"  Generalization gap      : {round(KAGGLE_F1 - attack_results['detection_pct'], 2)} pp")
    print(f"  Hosam et al. benchmark  : {HOSAM_BENCHMARK}%")
    print(f"  Delta vs. benchmark     : {attack_results['delta_vs_hosam_pp']:+.2f} pp")
    if fp_results:
        print(f"  False positive rate     : {fp_results['false_positive_pct']}%")
    print("=" * 55)
    print("\n  Add Section 6.7 to your thesis Chapter 6 with these results.")
    print("=" * 55)

    return report


if __name__ == "__main__":
    run_generalization_test()
