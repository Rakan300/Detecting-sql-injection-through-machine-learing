"""
SQL Injection Detection — WAF Inference Module
===============================================
Author  : Rakan Abunamoos
Thesis  : Detection of SQL Injection Using Machine Learning (XGBoost)
Uni     : Uskudar University — Cybersecurity MSc 2025-2026

This module is the WAF inference engine.
It loads scaler + model from model/ and classifies any SQL string in real-time.

Usage (standalone):
    python src/predict.py

Usage (import in Flask WAF):
    from src.predict import SQLInjectionDetector
    detector = SQLInjectionDetector()
    result   = detector.predict("SELECT * FROM users WHERE id=1 OR 1=1 --")
    print(result)   # {"label": 1, "verdict": "MALICIOUS", "confidence": 0.97, ...}

Input  : model/scaler.pkl
         model/xgboost_model.pkl
         model/model_metadata.json
"""

import os
import re
import json
import pickle
import time
import numpy as np

# ─── 0. PATHS ─────────────────────────────────────────────────────────────────

BASE_DIR      = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
MODEL_DIR     = os.path.join(BASE_DIR, "model")

SCALER_PATH   = os.path.join(MODEL_DIR, "scaler.pkl")
MODEL_PATH    = os.path.join(MODEL_DIR, "xgboost_model.pkl")
METADATA_PATH = os.path.join(MODEL_DIR, "model_metadata.json")

# ─── 1. SQL PATTERNS (must match preprocessing.py exactly) ────────────────────

SQL_KEYWORDS = [
    "select", "insert", "update", "delete", "drop", "create", "alter",
    "union", "from", "where", "having", "order", "group", "by", "join",
    "inner", "outer", "left", "right", "on", "into", "values", "set",
    "exec", "execute", "xp_", "sp_", "cast", "convert", "char", "nchar",
    "varchar", "declare", "table", "database", "schema", "truncate",
    "information_schema", "sysobjects", "syscolumns",
]

ALWAYS_TRUE_PATTERNS = [
    r"or\s+1\s*=\s*1",
    r"or\s+'[^']*'\s*=\s*'[^']*'",
    r"or\s+\"[^\"]*\"\s*=\s*\"[^\"]*\"",
    r"or\s+true",
    r"1\s*=\s*1",
    r"'[^']+'\s*=\s*'[^']+'",
]

# ─── 2. PREPROCESSING (mirrors preprocessing.py) ──────────────────────────────

def clean_query(raw: str) -> str:
    if not isinstance(raw, str):
        return ""
    s = raw
    s = s.replace("%27", "'").replace("%22", '"')
    s = s.replace("%20", " ").replace("%09", "\t")
    s = s.replace("%2D", "-").replace("%23", "#")
    s = s.replace("%3D", "=").replace("%3B", ";")
    s = s.replace("+",   " ")
    s = re.sub(r"&[a-zA-Z]+;", " ", s)
    s = re.sub(r"&#\d+;",      " ", s)
    s = re.sub(r"\s+",         " ", s).strip()
    s = s.lower()
    return s


def extract_features(query: str) -> np.ndarray:
    q = query

    query_length    = len(q)
    num_keywords    = sum(len(re.findall(rf"\b{re.escape(kw)}\b", q)) for kw in SQL_KEYWORDS)
    num_special_chars = len(re.findall(r"['\"`]", q))
    num_comments    = len(re.findall(r"(--|#|/\*|\*/)", q))
    num_semicolons  = q.count(";")
    num_arithmetic  = len(re.findall(r"(=|<|>|!=|<>|\band\b|\bor\b|\bnot\b)", q))
    num_union       = len(re.findall(r"\bunion\b", q))
    num_always_true = sum(len(re.findall(p, q)) for p in ALWAYS_TRUE_PATTERNS)

    return np.array([[
        query_length, num_keywords, num_special_chars,
        num_comments, num_semicolons, num_arithmetic,
        num_union, num_always_true,
    ]], dtype=float)

# ─── 3. DETECTOR CLASS ────────────────────────────────────────────────────────

class SQLInjectionDetector:
    """
    Loads the trained XGBoost model and scaler from model/.
    Call predict(query) for real-time WAF inference.

    Both scaler.pkl and xgboost_model.pkl must be in the same model/ folder —
    they were fitted together during preprocessing and training.
    """

    def __init__(self):
        self.scaler   = self._load_scaler()
        self.model    = self._load_model()
        self.metadata = self._load_metadata()
        print("[DETECTOR] Ready — model + scaler loaded from model/")

    def _load_scaler(self):
        if not os.path.exists(SCALER_PATH):
            raise FileNotFoundError(
                f"Scaler not found at {SCALER_PATH}\n"
                "Run preprocessing.py first."
            )
        with open(SCALER_PATH, "rb") as f:
            return pickle.load(f)

    def _load_model(self):
        if not os.path.exists(MODEL_PATH):
            raise FileNotFoundError(
                f"Model not found at {MODEL_PATH}\n"
                "Run train.py first."
            )
        with open(MODEL_PATH, "rb") as f:
            return pickle.load(f)

    def _load_metadata(self):
        if os.path.exists(METADATA_PATH):
            with open(METADATA_PATH) as f:
                return json.load(f)
        return {}

    def predict(self, raw_query: str) -> dict:
        """
        Classify a single raw SQL string.

        Returns:
            {
              "label":       0 or 1,
              "verdict":     "BENIGN" or "MALICIOUS",
              "confidence":  float (0.0 – 1.0),
              "latency_ms":  float,
              "query":       original input string
            }
        """
        t0 = time.perf_counter()

        cleaned   = clean_query(raw_query)
        features  = extract_features(cleaned)
        scaled    = self.scaler.transform(features)   # use fitted scaler — never refit
        label     = int(self.model.predict(scaled)[0])
        prob      = float(self.model.predict_proba(scaled)[0][1])
        latency   = round((time.perf_counter() - t0) * 1000, 3)

        verdict = "MALICIOUS" if label == 1 else "BENIGN"

        return {
            "label":      label,
            "verdict":    verdict,
            "confidence": round(prob, 4),
            "latency_ms": latency,
            "query":      raw_query,
        }

    def predict_batch(self, queries: list) -> list:
        """Classify a list of queries. Returns a list of result dicts."""
        return [self.predict(q) for q in queries]

# ─── 4. DEMO ──────────────────────────────────────────────────────────────────

TEST_QUERIES = [
    # Benign
    ("SELECT * FROM products WHERE category = 'electronics'",          0),
    ("INSERT INTO orders (user_id, total) VALUES (42, 99.99)",         0),
    ("What is the price of the blue chair?",                           0),
    ("admin",                                                          0),
    # Malicious
    ("' OR 1=1 --",                                                    1),
    ("' UNION SELECT username, password FROM users --",                1),
    ("'; DROP TABLE users; --",                                        1),
    ("' AND extractvalue(1, concat(0x7e,(SELECT version()))) --",      1),
    ("'; IF (1=1) WAITFOR DELAY '0:0:5' --",                           1),
    ("' OR 'a'='a",                                                    1),
]


def run_demo():
    print("=" * 60)
    print("  SQL INJECTION — WAF PREDICT DEMO")
    print("=" * 60)

    detector = SQLInjectionDetector()

    print(f"\n{'Query':<50} {'Expected':<12} {'Verdict':<12} {'Conf':>6} {'ms':>7}")
    print("─" * 90)

    correct = 0
    for query, expected in TEST_QUERIES:
        result   = detector.predict(query)
        match    = "✅" if result["label"] == expected else "❌"
        expected_str = "MALICIOUS" if expected == 1 else "BENIGN"
        print(
            f"{query[:48]:<50} "
            f"{expected_str:<12} "
            f"{result['verdict']:<12} "
            f"{result['confidence']:>6.3f} "
            f"{result['latency_ms']:>6.2f}ms  {match}"
        )
        if result["label"] == expected:
            correct += 1

    print("─" * 90)
    print(f"\n  Accuracy on demo set: {correct}/{len(TEST_QUERIES)}  "
          f"({correct/len(TEST_QUERIES)*100:.0f}%)")
    print("\n  ✅ WAF inference module ready for DVWA integration.")
    print("=" * 60)


if __name__ == "__main__":
    run_demo()
