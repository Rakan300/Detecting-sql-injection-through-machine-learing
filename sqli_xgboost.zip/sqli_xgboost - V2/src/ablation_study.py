"""
SQL Injection Detection — Ablation Study
=========================================
Author  : Rakan Abunamoos
Thesis  : Detection of SQL Injection Using Machine Learning (XGBoost)
Uni     : Uskudar University — Cybersecurity MSc 2025-2026

PURPOSE:
  Removes each of the 8 features one at a time, retrains XGBoost
  with the same best hyperparameters, and records the F1 drop.
  Answers: which features are truly necessary?

Output : results/ablation_report.json
         results/ablation_chart.png

Run    : python src/ablation_study.py
"""

import os
import json
import pickle
import numpy as np
import pandas as pd
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
from sklearn.metrics import f1_score
from xgboost import XGBClassifier

# ─── PATHS ────────────────────────────────────────────────────────────────────

BASE_DIR      = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
PROC_DIR      = os.path.join(BASE_DIR, "data",    "processed")
MODEL_DIR     = os.path.join(BASE_DIR, "model")
RESULTS_DIR   = os.path.join(BASE_DIR, "results")

TRAIN_PATH    = os.path.join(PROC_DIR,    "sqli_train.csv")
VAL_PATH      = os.path.join(PROC_DIR,    "sqli_val.csv")
METADATA_PATH = os.path.join(MODEL_DIR,   "model_metadata.json")
REPORT_PATH   = os.path.join(RESULTS_DIR, "ablation_report.json")
CHART_PATH    = os.path.join(RESULTS_DIR, "ablation_chart.png")

RANDOM_SEED = 42

# ─── LOAD ─────────────────────────────────────────────────────────────────────

def load_data():
    train_df = pd.read_csv(TRAIN_PATH)
    val_df   = pd.read_csv(VAL_PATH)

    feature_cols = [c for c in train_df.columns if c != "label"]
    X_train = train_df[feature_cols].values
    y_train = train_df["label"].values
    X_val   = val_df[feature_cols].values
    y_val   = val_df["label"].values

    with open(METADATA_PATH) as f:
        meta = json.load(f)

    print(f"[LOAD]  Train: {X_train.shape}  Val: {X_val.shape}")
    print(f"[LOAD]  Features: {feature_cols}")
    return X_train, y_train, X_val, y_val, feature_cols, meta


def load_best_params():
    """Load best hyperparameters found during training."""
    report_path = os.path.join(RESULTS_DIR, "training_report.json")
    if os.path.exists(report_path):
        with open(report_path) as f:
            report = json.load(f)
        params = report.get("best_params", {})
        print(f"[LOAD]  Best params from training_report.json: {params}")
        return params
    # Fallback to known best params from our training run
    fallback = {
        "n_estimators":     200,
        "max_depth":        7,
        "learning_rate":    0.1,
        "subsample":        0.9,
        "colsample_bytree": 0.8,
        "min_child_weight": 1,
    }
    print(f"[LOAD]  Using fallback best params: {fallback}")
    return fallback


def train_and_score(X_train, y_train, X_val, y_val,
                    scale_pos_weight, best_params) -> float:
    """Train XGBoost with given data and return val F1."""
    model = XGBClassifier(
        **best_params,
        scale_pos_weight = scale_pos_weight,
        eval_metric      = "logloss",
        random_state     = RANDOM_SEED,
        n_jobs           = -1,
    )
    model.fit(X_train, y_train)
    y_pred = model.predict(X_val)
    return f1_score(y_val, y_pred, zero_division=0)

# ─── ABLATION ─────────────────────────────────────────────────────────────────

def run_ablation(X_train, y_train, X_val, y_val,
                 feature_cols, meta, best_params):

    scale_pos_weight = meta["scale_pos_weight"]

    # Baseline: all 8 features
    print("\n[ABLATION] Training baseline (all 8 features) ...")
    baseline_f1 = train_and_score(
        X_train, y_train, X_val, y_val,
        scale_pos_weight, best_params
    )
    print(f"[ABLATION] Baseline F1 = {baseline_f1:.4f}")

    results = []

    for i, feat in enumerate(feature_cols):
        # Remove feature i
        keep_idx = [j for j in range(len(feature_cols)) if j != i]
        X_tr_reduced = X_train[:, keep_idx]
        X_vl_reduced = X_val[:,   keep_idx]

        f1 = train_and_score(
            X_tr_reduced, y_train,
            X_vl_reduced, y_val,
            scale_pos_weight, best_params
        )
        drop = baseline_f1 - f1
        pct_drop = drop / baseline_f1 * 100

        results.append({
            "feature":      feat,
            "f1_without":   round(f1,       4),
            "f1_drop":      round(drop,     4),
            "pct_drop":     round(pct_drop, 2),
            "importance":   "critical" if pct_drop > 1.0
                            else "important" if pct_drop > 0.3
                            else "moderate" if pct_drop > 0.1
                            else "redundant"
        })

        flag = " ◀ CRITICAL" if pct_drop > 1.0 else \
               " ◀ important" if pct_drop > 0.3 else ""
        print(f"  Remove {feat:<25} → F1={f1:.4f}  drop={drop:+.4f} "
              f"({pct_drop:+.2f}%){flag}")

    # Sort by F1 drop descending (most important first)
    results.sort(key=lambda x: x["f1_drop"], reverse=True)

    return baseline_f1, results

# ─── PLOT ─────────────────────────────────────────────────────────────────────

def save_chart(baseline_f1, results, output_path):
    features   = [r["feature"]    for r in results]
    f1_without = [r["f1_without"] for r in results]
    drops      = [r["f1_drop"]    for r in results]

    # Color by importance
    colors = []
    for r in results:
        if r["importance"] == "critical":
            colors.append("#D85A30")
        elif r["importance"] == "important":
            colors.append("#BA7517")
        elif r["importance"] == "moderate":
            colors.append("#3B8BD4")
        else:
            colors.append("#AAAAAA")

    fig, axes = plt.subplots(1, 2, figsize=(14, 5))
    fig.suptitle("Feature Ablation Study — XGBoost SQL Injection Detector",
                 fontsize=13, fontweight="bold")

    # Plot 1: F1 when feature removed
    ax = axes[0]
    bars = ax.barh(features, f1_without, color=colors, edgecolor="white")
    ax.axvline(x=baseline_f1, color="#1D9E75", linestyle="--",
               linewidth=1.5, label=f"Baseline F1 = {baseline_f1:.4f}")
    ax.set_xlabel("F1-score (without this feature)")
    ax.set_title("F1-score With Each Feature Removed")
    ax.set_xlim(min(f1_without) - 0.01, 1.0)
    ax.legend(fontsize=9)
    ax.spines[["top", "right"]].set_visible(False)
    for bar, val in zip(bars, f1_without):
        ax.text(val + 0.0005, bar.get_y() + bar.get_height()/2,
                f"{val:.4f}", va="center", fontsize=9)

    # Plot 2: F1 drop
    ax = axes[1]
    drop_colors = ["#D85A30" if d > 0.001 else "#AAAAAA" for d in drops]
    bars = ax.barh(features, [d * 100 for d in drops],
                   color=drop_colors, edgecolor="white")
    ax.set_xlabel("F1 Drop (%)")
    ax.set_title("F1 Drop When Feature Removed\n(larger = more important)")
    ax.spines[["top", "right"]].set_visible(False)
    for bar, val in zip(bars, drops):
        ax.text(val * 100 + 0.001, bar.get_y() + bar.get_height()/2,
                f"{val*100:.3f}%", va="center", fontsize=9)

    # Legend
    from matplotlib.patches import Patch
    legend_elements = [
        Patch(facecolor="#D85A30", label="Critical (>1% drop)"),
        Patch(facecolor="#BA7517", label="Important (>0.3% drop)"),
        Patch(facecolor="#3B8BD4", label="Moderate (>0.1% drop)"),
        Patch(facecolor="#AAAAAA", label="Redundant (≤0.1% drop)"),
    ]
    fig.legend(handles=legend_elements, loc="lower center",
               ncol=4, fontsize=9, bbox_to_anchor=(0.5, -0.04))

    plt.tight_layout()
    plt.savefig(output_path, dpi=150, bbox_inches="tight")
    plt.close()
    print(f"[PLOT]  Ablation chart → {output_path}")

# ─── MAIN ─────────────────────────────────────────────────────────────────────

def run_ablation_study():
    os.makedirs(RESULTS_DIR, exist_ok=True)

    print("=" * 60)
    print("  SQL INJECTION — FEATURE ABLATION STUDY")
    print("=" * 60)

    X_train, y_train, X_val, y_val, feature_cols, meta = load_data()
    best_params = load_best_params()

    baseline_f1, results = run_ablation(
        X_train, y_train, X_val, y_val,
        feature_cols, meta, best_params
    )

    save_chart(baseline_f1, results, CHART_PATH)

    # Save report
    report = {
        "baseline_f1":  round(baseline_f1, 4),
        "feature_cols": feature_cols,
        "results":      results,
    }
    with open(REPORT_PATH, "w") as f:
        json.dump(report, f, indent=2)
    print(f"[SAVE]  Report → {REPORT_PATH}")

    # Summary table
    print("\n" + "=" * 60)
    print("  ABLATION STUDY COMPLETE")
    print("=" * 60)
    print(f"  Baseline F1 (all 8 features) : {baseline_f1:.4f}")
    print(f"\n  {'Feature':<25} {'F1 without':>10} {'Drop':>8} {'Category':>12}")
    print(f"  {'─'*25} {'─'*10} {'─'*8} {'─'*12}")
    for r in results:
        print(f"  {r['feature']:<25} {r['f1_without']:>10.4f} "
              f"{r['pct_drop']:>+7.2f}%  {r['importance']:>12}")
    print("=" * 60)
    print("\n  Add Table 6.8 + Figure 6.7 to thesis Chapter 6")
    print("=" * 60)

    return report


if __name__ == "__main__":
    run_ablation_study()
