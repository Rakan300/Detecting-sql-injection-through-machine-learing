"""
SQL Injection Detection — XGBoost Training
==========================================
Author  : Rakan Abunamoos
Thesis  : Detection of SQL Injection Using Machine Learning (XGBoost)
Uni     : Uskudar University — Cybersecurity MSc 2025-2026

Input  : data/processed/sqli_train.csv
         data/processed/sqli_val.csv
         model/model_metadata.json

Output : model/xgboost_model.pkl
         results/training_report.json
         results/confusion_matrix.png
         results/roc_curve.png
         results/feature_importance.png

Run    : python src/train.py
"""

import os
import json
import pickle
import time
import numpy as np
import pandas as pd
import matplotlib.pyplot as plt
import seaborn as sns
from sklearn.metrics import (
    accuracy_score, precision_score, recall_score,
    f1_score, roc_auc_score, confusion_matrix, roc_curve,
)
from sklearn.model_selection import RandomizedSearchCV, StratifiedKFold
from xgboost import XGBClassifier

# ─── 0. PATHS ─────────────────────────────────────────────────────────────────

BASE_DIR      = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
PROC_DIR      = os.path.join(BASE_DIR, "data",    "processed")
MODEL_DIR     = os.path.join(BASE_DIR, "model")
RESULTS_DIR   = os.path.join(BASE_DIR, "results")

TRAIN_PATH    = os.path.join(PROC_DIR,    "sqli_train.csv")
VAL_PATH      = os.path.join(PROC_DIR,    "sqli_val.csv")
METADATA_PATH = os.path.join(MODEL_DIR,   "model_metadata.json")
MODEL_PATH    = os.path.join(MODEL_DIR,   "xgboost_model.pkl")
REPORT_PATH   = os.path.join(RESULTS_DIR, "training_report.json")
CM_PATH       = os.path.join(RESULTS_DIR, "confusion_matrix.png")
ROC_PATH      = os.path.join(RESULTS_DIR, "roc_curve.png")
FI_PATH       = os.path.join(RESULTS_DIR, "feature_importance.png")

RANDOM_SEED = 42

# ─── 1. LOAD DATA ─────────────────────────────────────────────────────────────

def load_splits():
    train_df = pd.read_csv(TRAIN_PATH)
    val_df   = pd.read_csv(VAL_PATH)

    X_train = train_df.drop(columns=["label"]).values
    y_train = train_df["label"].values
    X_val   = val_df.drop(columns=["label"]).values
    y_val   = val_df["label"].values

    feature_cols = [c for c in train_df.columns if c != "label"]

    print(f"[LOAD]  Train: {X_train.shape}  |  Val: {X_val.shape}")
    return X_train, y_train, X_val, y_val, feature_cols


def load_metadata():
    with open(METADATA_PATH) as f:
        return json.load(f)

# ─── 2. HYPERPARAMETER SEARCH ─────────────────────────────────────────────────

def tune_xgboost(X_train, y_train, scale_pos_weight: float):
    """
    RandomizedSearchCV — tests 20 random combinations instead of 540.
    ~10x faster than GridSearch, same quality result.
    Scored on F1 (binary) using 5-fold stratified CV.
    """
    print("\n[TUNE]  Starting RandomizedSearchCV")
    print("        20 iterations x 5-fold = 100 fits")
    print("        Estimated time: 1–3 minutes ...\n")

    param_dist = {
        "n_estimators":     [100, 200, 300, 500],
        "max_depth":        [3, 4, 5, 6, 7],
        "learning_rate":    [0.01, 0.05, 0.1, 0.2],
        "subsample":        [0.7, 0.8, 0.9, 1.0],
        "colsample_bytree": [0.7, 0.8, 0.9, 1.0],
        "min_child_weight": [1, 3, 5],
    }

    # use_label_encoder removed — deprecated in newer XGBoost versions
    base_model = XGBClassifier(
        scale_pos_weight = scale_pos_weight,
        eval_metric      = "logloss",
        random_state     = RANDOM_SEED,
        n_jobs           = 1,           # 1 job per model; parallelism via cv
    )

    cv = StratifiedKFold(n_splits=5, shuffle=True, random_state=RANDOM_SEED)

    search = RandomizedSearchCV(
        estimator           = base_model,
        param_distributions = param_dist,
        n_iter              = 20,
        scoring             = "f1",
        cv                  = cv,
        verbose             = 1,
        n_jobs              = -1,       # parallel CV folds
        random_state        = RANDOM_SEED,
        refit               = True,
    )

    t0 = time.time()
    search.fit(X_train, y_train)
    elapsed = round(time.time() - t0, 1)

    print(f"\n[TUNE]  Best params  : {search.best_params_}")
    print(f"[TUNE]  Best CV F1   : {search.best_score_:.4f}")
    print(f"[TUNE]  Time elapsed : {elapsed}s")

    return search.best_estimator_, search.best_params_, search.best_score_

# ─── 3. EVALUATION HELPERS ────────────────────────────────────────────────────

def compute_metrics(model, X, y, split_name: str) -> dict:
    y_pred = model.predict(X)
    y_prob = model.predict_proba(X)[:, 1]

    acc  = accuracy_score(y, y_pred)
    prec = precision_score(y, y_pred, zero_division=0)
    rec  = recall_score(y, y_pred, zero_division=0)
    f1   = f1_score(y, y_pred, zero_division=0)
    auc  = roc_auc_score(y, y_prob)

    print(f"\n[{split_name.upper()}]")
    print(f"  Accuracy  : {acc:.4f}")
    print(f"  Precision : {prec:.4f}")
    print(f"  Recall    : {rec:.4f}")
    print(f"  F1-score  : {f1:.4f}")
    print(f"  AUC-ROC   : {auc:.4f}")

    return {
        "accuracy":  round(acc,  4),
        "precision": round(prec, 4),
        "recall":    round(rec,  4),
        "f1":        round(f1,   4),
        "auc_roc":   round(auc,  4),
    }

# ─── 4. PLOTS ─────────────────────────────────────────────────────────────────

def plot_confusion_matrix(model, X_val, y_val, output_path: str):
    y_pred = model.predict(X_val)
    cm = confusion_matrix(y_val, y_pred)

    fig, ax = plt.subplots(figsize=(6, 5))
    sns.heatmap(
        cm, annot=True, fmt="d", cmap="Blues",
        xticklabels=["Benign", "Malicious"],
        yticklabels=["Benign", "Malicious"],
        ax=ax, linewidths=0.5,
    )
    ax.set_xlabel("Predicted Label", fontsize=12)
    ax.set_ylabel("True Label",      fontsize=12)
    ax.set_title("Confusion Matrix — Validation Set", fontsize=13, fontweight="bold")
    plt.tight_layout()
    plt.savefig(output_path, dpi=150, bbox_inches="tight")
    plt.close()
    print(f"[PLOT]  Confusion matrix    → {output_path}")

    tn, fp, fn, tp = cm.ravel()
    print(f"        TP:{tp}  TN:{tn}  FP:{fp}  FN:{fn}")


def plot_roc_curve(model, X_val, y_val, output_path: str):
    y_prob = model.predict_proba(X_val)[:, 1]
    fpr, tpr, _ = roc_curve(y_val, y_prob)
    auc = roc_auc_score(y_val, y_prob)

    fig, ax = plt.subplots(figsize=(6, 5))
    ax.plot(fpr, tpr, color="#3B8BD4", lw=2, label=f"XGBoost (AUC = {auc:.4f})")
    ax.plot([0, 1], [0, 1], color="gray", linestyle="--", lw=1, label="Random")
    ax.fill_between(fpr, tpr, alpha=0.1, color="#3B8BD4")
    ax.set_xlabel("False Positive Rate", fontsize=12)
    ax.set_ylabel("True Positive Rate",  fontsize=12)
    ax.set_title("ROC Curve — Validation Set", fontsize=13, fontweight="bold")
    ax.legend(loc="lower right")
    ax.spines[["top", "right"]].set_visible(False)
    plt.tight_layout()
    plt.savefig(output_path, dpi=150, bbox_inches="tight")
    plt.close()
    print(f"[PLOT]  ROC curve           → {output_path}")


def plot_feature_importance(model, feature_cols: list, output_path: str):
    importance = model.feature_importances_
    fi_df = pd.DataFrame({
        "feature":    feature_cols,
        "importance": importance,
    }).sort_values("importance", ascending=True)

    fig, ax = plt.subplots(figsize=(7, 5))
    colors = ["#D85A30" if v == fi_df["importance"].max()
              else "#3B8BD4" for v in fi_df["importance"]]
    ax.barh(fi_df["feature"], fi_df["importance"], color=colors, edgecolor="white")
    ax.set_xlabel("Feature Importance (gain)", fontsize=12)
    ax.set_title("XGBoost Feature Importance", fontsize=13, fontweight="bold")
    ax.spines[["top", "right"]].set_visible(False)

    for i, val in enumerate(fi_df["importance"]):
        ax.text(val + 0.001, i, f"{val:.3f}", va="center", fontsize=9)

    plt.tight_layout()
    plt.savefig(output_path, dpi=150, bbox_inches="tight")
    plt.close()
    print(f"[PLOT]  Feature importance  → {output_path}")

# ─── 5. SAVE MODEL ────────────────────────────────────────────────────────────

def save_model(model, path: str):
    os.makedirs(os.path.dirname(path), exist_ok=True)
    with open(path, "wb") as f:
        pickle.dump(model, f)
    print(f"[MODEL] XGBoost model saved → {path}")

# ─── 6. MAIN ──────────────────────────────────────────────────────────────────

def run_training():
    os.makedirs(RESULTS_DIR, exist_ok=True)

    print("=" * 60)
    print("  SQL INJECTION — XGBOOST TRAINING")
    print("=" * 60)

    X_train, y_train, X_val, y_val, feature_cols = load_splits()
    meta = load_metadata()
    scale_pos_weight = meta["scale_pos_weight"]
    print(f"[INFO]  scale_pos_weight = {scale_pos_weight}")
    print(f"[INFO]  Features         = {feature_cols}")

    best_model, best_params, best_cv_f1 = tune_xgboost(
        X_train, y_train, scale_pos_weight
    )

    train_metrics = compute_metrics(best_model, X_train, y_train, "TRAIN")
    val_metrics   = compute_metrics(best_model, X_val,   y_val,   "VAL")

    target_met = val_metrics["f1"] >= 0.95
    print(f"\n[TARGET] F1 >= 0.95 -> {'MET' if target_met else 'NOT MET'} "
          f"(val F1 = {val_metrics['f1']:.4f})")

    plot_confusion_matrix(best_model, X_val, y_val, CM_PATH)
    plot_roc_curve(best_model,        X_val, y_val, ROC_PATH)
    plot_feature_importance(best_model, feature_cols, FI_PATH)

    save_model(best_model, MODEL_PATH)

    report = {
        "best_params":      best_params,
        "best_cv_f1":       round(best_cv_f1, 4),
        "train_metrics":    train_metrics,
        "val_metrics":      val_metrics,
        "f1_target_met":    target_met,
        "feature_cols":     feature_cols,
        "scale_pos_weight": scale_pos_weight,
    }
    with open(REPORT_PATH, "w") as f:
        json.dump(report, f, indent=2)
    print(f"[SAVE]  Training report    -> {REPORT_PATH}")

    print("\n" + "=" * 60)
    print("  TRAINING COMPLETE")
    print("=" * 60)
    print(f"  Val Accuracy  : {val_metrics['accuracy']:.4f}")
    print(f"  Val Precision : {val_metrics['precision']:.4f}")
    print(f"  Val Recall    : {val_metrics['recall']:.4f}")
    print(f"  Val F1-score  : {val_metrics['f1']:.4f}")
    print(f"  Val AUC-ROC   : {val_metrics['auc_roc']:.4f}")
    print(f"  F1 >= 0.95    : {'MET' if target_met else 'NOT MET'}")
    print("=" * 60)
    print("\n  Next step -> run:  python src/evaluate.py")
    print("=" * 60)

    return best_model, report


if __name__ == "__main__":
    run_training()
